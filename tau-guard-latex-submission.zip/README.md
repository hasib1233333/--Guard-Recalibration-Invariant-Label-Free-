# tau-Guard: LaTeX Submission Package

This package contains the complete, self-contained LaTeX source for the
manuscript "tau-Guard: Recalibration-Invariant, Label-Free Drift Detection
via Cross-Signal Rank-Agreement Decay" (Md Hasibuzzaman), formatted for ACM
AI Letters (AILET) using the ACM `acmart` class, with IEEE-style numbered
citations (via `IEEEtran.bst`).

## Files

- `main.tex` -- the manuscript source
- `references.bib` -- BibTeX bibliography (all entries verified against
  primary sources)
- `main.bbl` -- pre-compiled bibliography (included so the package compiles
  even without running BibTeX, though running BibTeX fresh is recommended
  and will reproduce the same output)
- `acmart.cls` -- the ACM article class (bundled for zero-friction
  compilation; not part of a default TeX Live install)
- `IEEEtran.bst` -- the IEEE bibliography style (bundled for the same reason)
- `figure1.pdf` ... `figure8.pdf` -- all eight figures, referenced exactly by
  these filenames in `main.tex`
- `main.pdf` -- the pre-compiled output, included for convenience

## Compiling

This package is fully self-contained: compiling requires only a standard
LaTeX installation (for base packages such as `amsmath`, `booktabs`,
`multirow`, `graphicx`) plus the two bundled files above. From this
directory:

```
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

This was verified to compile with zero errors and zero undefined references
from a clean directory containing only the files listed above (i.e., with no
reliance on any pre-installed `acmart` or `IEEEtran` on the compiling
machine).

## Figure correspondence

1. `figure1.pdf` -- tau-Guard pipeline schematic (training/calibration/deployment)
2. `figure2.pdf` -- recalibration illustration (rank order preserved under monotone remap)
3. `figure3.pdf` -- control vs. recalibration FPR, six methods, core datasets
4. `figure4.pdf` -- shift-detection gap, six methods, core datasets
5. `figure5.pdf` -- classifier-generality comparison (LogReg / RF / SVM)
6. `figure6.pdf` -- runtime and storage complexity comparison
7. `figure7.pdf` -- ablation and sensitivity panel (window size, calibration ratio, temperature, novelty score)
8. `figure8.pdf` -- Electricity real-world case study (accuracy and alarm timelines)

The code used to generate every figure and every number in this manuscript
is provided in the accompanying code package.
