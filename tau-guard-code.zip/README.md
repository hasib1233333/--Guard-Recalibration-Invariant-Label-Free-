# tau-Guard: Code and Results

This package contains all code, raw results, and downloaded datasets needed to
reproduce every number, table, and figure in the manuscript "tau-Guard:
Recalibration-Invariant, Label-Free Drift Detection via Cross-Signal
Rank-Agreement Decay" (Md Hasibuzzaman).

## Directory structure

- `src/` -- all Python source code (pipeline scripts)
- `results/` -- raw JSON result files produced by the scripts below (already
  generated; re-running the scripts will regenerate them)
- `data/` -- real datasets downloaded from public sources (see provenance
  below); `synthetic`, `breast_cancer`, `digits`, and `wine` are not included
  here as they are bundled with scikit-learn / generated on the fly.

## Reproduction pipeline (run in this order)

1. `python3 src/data_loaders.py` -- sanity-checks that all 8 classification
   datasets load with the expected shapes.
2. `python3 src/run_expanded_study.py` -- runs the full 6-method (tau-Guard,
   Confidence-KS, PSI, Feature-MMD, STUDD, D3) comparison across the core
   3-dataset battery (5 seeds), the extended 5-dataset battery (3 seeds), and
   the 3-classifier generality battery (3 seeds). Produces:
   `core_6method_results.json`, `extended_dataset_results.json`,
   `clf_logreg_results.json`, `clf_rf_results.json`, `clf_svm_results.json`.
   (Note: this is long-running; the version used here was executed in
   per-seed chunks with incremental saving -- see `run_dataset_battery`'s
   `save_path` argument.)
3. `python3 src/analyze_v2.py` -- consolidates the above into pooled
   statistics, confidence intervals, and McNemar/Wilcoxon tests. Produces
   `analysis_v2_summary.json` and prints all tables used in the paper.
4. `python3 src/ablation.py` -- window size, bootstrap size, novelty-score
   choice, and rank-statistic ablations. Produces `ablation_results.json`.
5. `python3 src/sensitivity.py` -- alpha, temperature, and calibration-ratio
   sensitivity sweeps. Produces `sensitivity_results.json`.
6. `python3 src/runtime_benchmark.py` -- measured runtime/memory/storage
   comparison. Produces `runtime_benchmark.json`.
7. `python3 src/electricity_case_study.py` -- real-world Electricity
   concept-drift case study (chronological, no shuffling). Produces
   `electricity_case_study.json`.
8. `python3 src/make_figures_v2.py` and `python3 src/make_schematics.py` --
   regenerate all 8 figures (`figure1.pdf`-`figure8.pdf` in the LaTeX
   submission package) from the result files above.

Core method implementation (tau-Guard, all baselines, novelty scorers, rank
statistics) lives in `src/method.py`. Dataset-preparation and calibration
plumbing shared across scenarios lives in `src/experiment_core.py` and
`src/scenarios.py`.

## Data provenance

- `diabetes.csv` (Pima Indians Diabetes), `ionosphere.csv`, `sonar.csv`,
  `banknote.csv`: downloaded from
  `https://raw.githubusercontent.com/jbrownlee/Datasets/master/`, a public
  mirror of standard UCI Machine Learning Repository datasets.
- `electricity.csv` (elecNormNew, the standard real-world concept-drift
  benchmark): downloaded from
  `https://raw.githubusercontent.com/scikit-multiflow/streaming-datasets/master/elec.csv`.
- `breast_cancer`, `digits`, `wine`: loaded via `sklearn.datasets` (bundled).
- `synthetic`: generated via `sklearn.datasets.make_classification` with a
  fixed random seed (see `data_loaders.py`).

## Software versions used

Python 3.12, scikit-learn 1.8.0, SciPy, NumPy, pandas, statsmodels
(McNemar's test), matplotlib.

## Note on cleanup

An earlier exploratory pass of the classifier-generality and shift-detection
experiments contained two bugs that were found and fixed during this study:
(1) an invalid temperature-scaling proxy for SVM (using `decision_function`,
which is not a true pre-softmax logit for SVC), and (2) a shift-direction
construction that accidentally aligned with high-variance (low
Mahalanobis-sensitivity) directions, understating genuine-shift detection
power. The result files in this package reflect the corrected pipeline only;
earlier, superseded intermediate files were removed before packaging to
avoid any ambiguity about which numbers are reported in the paper.
