# tau-Guard: Code and Results

This package contains all code, raw results, and downloaded datasets needed to
reproduce every number, table, and figure in the manuscript "tau-Guard:
Recalibration-Invariant, Label-Free Drift Detection via Cross-Signal
Rank-Agreement Decay" (Md Hasibuzzaman).

## Directory structure

- `src/` -- all Python source code (pipeline scripts)
- `results/` -- raw JSON result files produced by the scripts below (already
  generated; re-running the scripts will regenerate them)
- `data/` -- real datasets downloaded from public sources (see provenance
  below); `synthetic`, `breast_cancer`, `digits`, and `wine` are not included
  here as they are bundled with scikit-learn / generated on the fly.

## Reproduction pipeline (run in this order)

1. `python3 src/data_loaders.py` -- sanity-checks that all 8 classification
   datasets load with the expected shapes.
2. `python3 src/run_expanded_study.py` -- runs the full 6-method (tau-Guard,
   Confidence-KS, PSI, Feature-MMD, STUDD, D3) comparison across the core
   3-dataset battery (5 seeds), the extended 5-dataset battery (3 seeds), and
   the 3-classifier generality battery (3 seeds). Produces:
   `core_6method_results.json`, `extended_dataset_results.json`,
   `clf_logreg_results.json`, `clf_rf_results.json`, `clf_svm_results.json`.
   (Note: this is long-running; the version used here was executed in
   per-seed chunks with incremental saving -- see `run_dataset_battery`'s
   `save_path` argument.)
3. `python3 src/analyze_v2.py` -- consolidates the above into pooled
   statistics, confidence intervals, and McNemar/Wilcoxon tests. Produces
   `analysis_v2_summary.json` and prints all tables used in the paper.
4. `python3 src/ablation.py` -- window size, bootstrap size, novelty-score
   choice, and rank-statistic ablations. Produces `ablation_results.json`.
5. `python3 src/sensitivity.py` -- alpha, temperature, and calibration-ratio
   sensitivity sweeps. Produces `sensitivity_results.json`.
6. `python3 src/runtime_benchmark.py` -- measured runtime/memory/storage
   comparison. Produces `runtime_benchmark.json`.
7. `python3 src/electricity_case_study.py` -- real-world Electricity
   concept-drift case study (chronological, no shuffling). Produces
   `electricity_case_study.json`.
8. `python3 src/make_figures_v2.py` and `python3 src/make_schematics.py` --
   regenerate all 8 figures (`figure1.pdf`-`figure8.pdf` in the LaTeX
   submission package) from the result files above.

Core method implementation (tau-Guard, all baselines, novelty scorers, rank
statistics) lives in `src/method.py`. Dataset-preparation and calibration
plumbing shared across scenarios lives in `src/experiment_core.py` and
`src/scenarios.py`.

## Data provenance

- `diabetes.csv` (Pima Indians Diabetes), `ionosphere.csv`, `sonar.csv`,
  `banknote.csv`: downloaded from
  `https://raw.githubusercontent.com/jbrownlee/Datasets/master/`, a public
  mirror of standard UCI Machine Learning Repository datasets.
- `electricity.csv` (elecNormNew, the standard real-world concept-drift
  benchmark): downloaded from
  `https://raw.githubusercontent.com/scikit-multiflow/streaming-datasets/master/elec.csv`.
- `breast_cancer`, `digits`, `wine`: loaded via `sklearn.datasets` (bundled).
- `synthetic`: generated via `sklearn.datasets.make_classification` with a
  fixed random seed (see `data_loaders.py`).

## Software versions used

Python 3.12, scikit-learn 1.8.0, SciPy, NumPy, pandas, statsmodels
(McNemar's test), matplotlib.

## Note on cleanup

An earlier exploratory pass of the classifier-generality and shift-detection
experiments contained two bugs that were found and fixed during this study:
(1) an invalid temperature-scaling proxy for SVM (using `decision_function`,
which is not a true pre-softmax logit for SVC), and (2) a shift-direction
construction that accidentally aligned with high-variance (low
Mahalanobis-sensitivity) directions, understating genuine-shift detection
power. The result files in this package reflect the corrected pipeline only;
earlier, superseded intermediate files were removed before packaging to
avoid any ambiguity about which numbers are reported in the paper.

A third, more subtle bug was found later, while preparing the deep-vision
extension: `mmd_baseline_test` (in `method.py`) compared each test window
against a *fixed* truncated slice of the calibration reference array, rather
than a freshly resampled subset matching the window size -- inconsistent
with the fresh-pairs bootstrap calibration protocol used everywhere else.
This was mostly benign on the original 10-dimensional PCA-reduced tabular
embeddings (modestly inflating Feature-MMD's false-positive rate, e.g.
`digits` control FPR 0.15 vs. the corrected 0.04) but became severe on the
64-dimensional real deep-vision embeddings (FPR 0.95 before the fix). The
fix is in the current `method.py` (`mmd_baseline_test` now takes an `rng`
argument and resamples the reference on every call). **All result files in
this package (`core_6method_results.json`, `extended_dataset_results.json`,
`deep_vision_results.json`) reflect the corrected implementation** -- we
reran the full core and extended tabular batteries after the fix rather
than leaving stale, miscalibrated Feature-MMD numbers in place.

## Deep-vision extension

`deep_vision_features.py` and `deep_vision_experiment.py` implement the
real deep-vision validation described in the paper: two genuinely
pretrained CIFAR-10 CNNs -- ResNet-20 and RepVGG-A0 (both via
`chenyaofo/pytorch-cifar-models`) -- evaluated on real CIFAR-10 images
(via the `YoongiKim/CIFAR-10-images` GitHub mirror) under real
CIFAR-10-C-style corruptions (Gaussian noise, motion blur, brightness,
contrast; implemented directly rather than via an external corruption
package). Requires `torch` and `torchvision` (CPU-only inference is
sufficient; no GPU or training is required, only inference through a
pretrained network). Run `python3 deep_vision_experiment.py resnet20` or
`python3 deep_vision_experiment.py repvgg_a0` (the latter uses reduced
trial counts and a 2-corruption subset for tractability, given RepVGG's
much larger 1280-dim embedding). `make_deepvision_figures.py` and
`make_cv_figures.py` generate the corresponding figures.

We searched for, but could not find, any publicly released pretrained
transformer (ViT/Swin) weights for CIFAR-10 accessible from a
network-restricted environment (only PyPI and GitHub are reachable; no
Hugging Face Hub or torchvision-hub access), and ImageNet-scale data was
infeasible given this environment's disk budget. RepVGG-A0 was chosen as
the best available real, architecturally-distinct, higher-dimensional
(1280-d vs. ResNet-20's 64-d) alternative.

## Additional novelty-score baseline (Energy)

`method.py` includes `EnergyNoveltyScorer`, implementing the energy score
of Liu et al. (NeurIPS 2020), $E(x) = -T\log\sum_k\exp(z_k(x)/T)$, computed
directly from classifier logits rather than a learned embedding. Used in
the extended novelty-score ablation (`ablation.py`,
`run_ablation_novelty_score`).

## CUSUM / sequential-testing extension

`cusum_extension.py` implements a two-sided CUSUM chart on the
standardized statistic $Z_t=(\hat\tau_t-\tau_0)/\sigma_0$, bootstrap-
calibrates its threshold to match the per-window test's Average Run
Length under $H_0$ (ARL$_0$), and compares detection delay against
per-window thresholding under the paper's standard genuine-shift scenario.
Produces `cusum_results.json`.

## Foundation-model + real-world domain-shift validation (CLIP + PACS)

`clip_pacs_experiment.py` implements a genuine transformer-based
foundation-model validation: real zero-shot classification with CLIP
ViT-B/32 (OpenCLIP weights trained on LAION-400M, downloaded from a public
GitHub release at `mlfoundations/open_clip`) on the real PACS dataset
(Photo/Art Painting/Cartoon/Sketch domains, downloaded from a public
GitHub mirror). This directly tests the recalibration-invariance property
on a real vision-language foundation model and on genuine cross-domain
photographic/artistic images -- not a synthetic corruption, and not a
tabular proxy for a camera-based deployment scenario. Requires
`open_clip_torch`, `tqdm`, `ftfy`, `regex` in addition to `torch`/
`torchvision`. `make_clip_pacs_figures.py` generates the corresponding
figures.

We note for reproducibility that we searched for, but could not access,
weights for other candidate foundation models: DINOv2 (hosted on Meta's
own CDN, `dl.fbaipublicfiles.com`, not GitHub) and the original OpenAI CLIP
checkpoints (hosted on `openaipublic.azureedge.net`). The specific
OpenCLIP release used here happens to be mirrored on GitHub, which is why
it was the model we could actually validate against.
