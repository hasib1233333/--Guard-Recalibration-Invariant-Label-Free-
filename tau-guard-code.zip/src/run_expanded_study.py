import json
import time
import numpy as np
from experiment_core import prepare_dataset, calibrate_all_methods
from scenarios import run_fpr_scenarios, run_shift_scenarios

CORE_DATASETS = ["breast_cancer", "synthetic", "digits"]
EXTENDED_DATASETS = ["wine", "diabetes", "ionosphere", "sonar", "banknote"]
ALL_METHODS = ("tau_guard", "ks", "psi", "mmd", "studd", "d3")


def run_dataset_battery(datasets, seeds, n_trials_fpr, n_trials_shift, clf_name="logreg", tag="",
                         save_path=None):
    all_results = {}
    if save_path is not None:
        try:
            all_results = json.load(open(save_path))
        except FileNotFoundError:
            all_results = {}
    for seed in seeds:
        if str(seed) in all_results:
            print(f"[{tag}] seed {seed} already done, skipping")
            continue
        rng = np.random.default_rng(seed)
        seed_results = {}
        for dsname in datasets:
            t0 = time.time()
            ds = prepare_dataset(dsname, clf_name, rng)
            calib = calibrate_all_methods(ds, rng, methods=ALL_METHODS)
            fpr_res = run_fpr_scenarios(ds, calib, rng, n_trials=n_trials_fpr)
            shift_res = {}
            if n_trials_shift > 0:
                shift_res = run_shift_scenarios(ds, calib, rng, n_trials=n_trials_shift)
            seed_results[dsname] = {"fpr": fpr_res, "shift": shift_res,
                                     "n_pool": int(ds["X_pool_s"].shape[0]),
                                     "n_calib": int(ds["s1_calib"].shape[0]),
                                     "window": ds["window"], "n_features": ds["n_features"]}
            elapsed = time.time() - t0
            ctrl = {m: round(float(np.mean(v)), 3) for m, v in fpr_res["control"].items()}
            recal = {m: round(float(np.mean(v)), 3) for m, v in fpr_res["recalibration"].items()}
            print(f"[{tag} seed {seed}] {dsname} ({clf_name}) [{elapsed:.1f}s]: control={ctrl} recal={recal}")
        all_results[str(seed)] = seed_results
        if save_path is not None:
            json.dump(all_results, open(save_path, "w"))
            print(f"[{tag}] seed {seed} saved to {save_path}")
    return all_results


def main():
    print("=== CORE 3 DATASETS: full 6-method comparison, 5 seeds ===")
    core_results = run_dataset_battery(CORE_DATASETS, [12345, 23456, 34567, 45678, 56789],
                                        n_trials_fpr=250, n_trials_shift=100, clf_name="logreg", tag="core")
    json.dump(core_results, open("/home/claude/paper/results/core_6method_results.json", "w"))

    print("=== EXTENDED 5 DATASETS: generalization check, 3 seeds ===")
    ext_results = run_dataset_battery(EXTENDED_DATASETS, [111, 222, 333],
                                       n_trials_fpr=200, n_trials_shift=80, clf_name="logreg", tag="ext")
    json.dump(ext_results, open("/home/claude/paper/results/extended_dataset_results.json", "w"))

    print("=== CLASSIFIER GENERALITY: 3 datasets x 3 classifiers, 3 seeds (FPR scenarios only) ===")
    clf_results = {}
    for clf_name in ["logreg", "rf", "svm"]:
        clf_results[clf_name] = run_dataset_battery(
            ["breast_cancer", "digits", "diabetes"], [1001, 2002, 3003],
            n_trials_fpr=200, n_trials_shift=0, clf_name=clf_name, tag=f"clf-{clf_name}")
    json.dump(clf_results, open("/home/claude/paper/results/classifier_generality_results.json", "w"))

    print("done.")


if __name__ == "__main__":
    main()
