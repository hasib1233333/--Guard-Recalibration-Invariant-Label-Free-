"""
Foundation-model + real-world-domain-shift validation: a genuine
pretrained CLIP (ViT-B/32, LAION-400M) evaluated via real zero-shot
classification on the real PACS dataset (Photo/Art/Cartoon/Sketch),
a standard domain-generalization benchmark of real photographs and
real stylistically-different images -- not a synthetic corruption, and
not a tabular proxy for a "camera-based" deployment scenario.
"""
import sys
sys.path.insert(0, "/home/claude/paper/src")
import glob
import json
import time
import numpy as np
import torch
import open_clip
from PIL import Image
from sklearn.linear_model import LogisticRegression

from method import (
    MahalanobisNoveltyScorer, predictive_entropy, calibrate_tau_guard, tau_guard_test,
    calibrate_ks_baseline, ks_baseline_test,
    calibrate_psi_baseline, psi_baseline_test,
    calibrate_mmd_baseline, mmd_baseline_test,
)

PACS_ROOT = "/home/claude/pacs_test/PACS"
CLASSES = ['dog', 'elephant', 'giraffe', 'guitar', 'horse', 'house', 'person']
WINDOW = 15
N_BOOTSTRAP = 1200
ALPHA = 0.05

_model, _preprocess, _tokenizer, _text_features = None, None, None, None


def get_clip():
    global _model, _preprocess, _tokenizer, _text_features
    if _model is None:
        _model, _, _preprocess = open_clip.create_model_and_transforms('ViT-B-32-quickgelu', pretrained=None)
        sd = torch.load("/home/claude/clip_vitb32.pt", map_location="cpu")
        _model.load_state_dict(sd)
        _model.eval()
        _tokenizer = open_clip.get_tokenizer('ViT-B-32-quickgelu')
        prompts = [f"a photo of a {c}" for c in CLASSES]
        with torch.no_grad():
            tf = _model.encode_text(_tokenizer(prompts))
            _text_features = tf / tf.norm(dim=-1, keepdim=True)
    return _model, _preprocess, _text_features


def load_domain_images(domain, n_per_class, seed=0, offset=0):
    rng = np.random.default_rng(seed)
    imgs, labels = [], []
    for ci, cls in enumerate(CLASSES):
        files = sorted(glob.glob(f"{PACS_ROOT}/{domain}/{cls}/*"))
        n_avail = max(len(files) - offset, 0)
        n_take = min(n_per_class, n_avail)
        idx = rng.choice(n_avail, size=n_take, replace=False) + offset if n_take > 0 else []
        for i in idx:
            imgs.append(Image.open(files[i]).convert("RGB"))
            labels.append(ci)
    labels = np.array(labels)
    perm = rng.permutation(len(imgs))
    return [imgs[i] for i in perm], labels[perm]


def extract_clip_features(images, T=100.0, batch_size=32):
    """Return (entropy s1, image-embedding s2_input [n,512], predicted label)."""
    model, preprocess, text_features = get_clip()
    entropies, embeddings, preds = [], [], []
    with torch.no_grad():
        for i in range(0, len(images), batch_size):
            batch = images[i:i + batch_size]
            imgs_t = torch.stack([preprocess(im) for im in batch])
            img_feat = model.encode_image(imgs_t)
            img_feat_n = img_feat / img_feat.norm(dim=-1, keepdim=True)
            logits = (T * img_feat_n @ text_features.T)
            proba = torch.softmax(logits, dim=1).numpy()
            ent = -np.sum(np.clip(proba, 1e-12, 1) * np.log(np.clip(proba, 1e-12, 1)), axis=1)
            entropies.append(ent)
            embeddings.append(img_feat.numpy())  # raw (unnormalized) embedding for novelty scorer
            preds.append(proba.argmax(axis=1))
    return np.concatenate(entropies), np.concatenate(embeddings), np.concatenate(preds)


def main():
    t0 = time.time()
    rng = np.random.default_rng(99)
    print("Loading real PACS images and extracting real CLIP zero-shot features...")
    train_imgs, train_labels = load_domain_images("photo", n_per_class=60, seed=1)
    calib_imgs, calib_labels = load_domain_images("photo", n_per_class=40, seed=2, offset=60)
    pool_imgs, pool_labels = load_domain_images("photo", n_per_class=40, seed=3, offset=100)

    s1_train, s2emb_train, preds_train = extract_clip_features(train_imgs)
    s1_calib, s2emb_calib, preds_calib = extract_clip_features(calib_imgs)
    s1_pool, s2emb_pool, preds_pool = extract_clip_features(pool_imgs)
    print(f"  train n={len(train_imgs)} calib n={len(calib_imgs)} pool n={len(pool_imgs)} [{time.time()-t0:.1f}s]")
    print(f"  zero-shot accuracy: train={ (preds_train==train_labels).mean():.3f} "
          f"calib={(preds_calib==calib_labels).mean():.3f} pool={(preds_pool==pool_labels).mean():.3f}")

    novelty = MahalanobisNoveltyScorer(shrinkage=5e-2).fit(s2emb_train, train_labels)
    s2_calib = novelty.score(s2emb_calib)
    s2_pool = novelty.score(s2emb_pool)

    print("Calibrating methods on real CLIP embeddings...")
    calib = {
        "tau_guard": calibrate_tau_guard(s1_calib, s2_calib, WINDOW, N_BOOTSTRAP, ALPHA, rng=np.random.default_rng(10)),
        "ks": calibrate_ks_baseline(s1_calib, WINDOW, N_BOOTSTRAP, ALPHA, rng=np.random.default_rng(11)),
        "psi": calibrate_psi_baseline(s1_calib, WINDOW, N_BOOTSTRAP, ALPHA, rng=np.random.default_rng(12)),
        "mmd": calibrate_mmd_baseline(s2emb_calib, WINDOW, N_BOOTSTRAP, ALPHA, rng=np.random.default_rng(13)),
    }
    print(f"  calibration done [{time.time()-t0:.1f}s]")

    # ---- Extract features for the OTHER real domains (genuine
    # distribution shift: real art/cartoon/sketch images, not corruption) ----
    other_domains = {}
    for domain in ["art_painting", "cartoon", "sketch"]:
        d_imgs, d_labels = load_domain_images(domain, n_per_class=40, seed=5)
        s1d, s2embd, predsd = extract_clip_features(d_imgs)
        s2d = novelty.score(s2embd)
        acc = (predsd == d_labels).mean()
        other_domains[domain] = {"s1": s1d, "s2emb": s2embd, "s2": s2d, "preds": predsd,
                                   "acc": float(acc), "n": len(d_imgs)}
        print(f"  domain={domain}: real zero-shot accuracy={acc:.3f} n={len(d_imgs)} [{time.time()-t0:.1f}s]")

    methods = ["tau_guard", "ks", "psi", "mmd"]

    def eval_window(s1, s2, s2emb):
        out = {}
        out["tau_guard"] = tau_guard_test(s1, s2, calib["tau_guard"])
        out["ks"] = ks_baseline_test(s1, calib["ks"])
        out["psi"] = psi_baseline_test(s1, calib["psi"])
        out["mmd"] = mmd_baseline_test(s2emb, calib["mmd"], rng=rng)
        return out

    # ---- Scenario A/B: control vs recalibration FPR (Photo-domain only) ----
    print("Running control/recalibration FPR trials (within-domain, Photo)...")
    n_trials_fpr = 120
    results_fpr = {"control": {m: [] for m in methods}, "recalibration": {m: [] for m in methods}}
    T_recal = 40.0  # a different (lower) logit_scale than the native ~100, i.e. genuine post-hoc recalibration
    s1_pool_recal, _, _ = extract_clip_features(pool_imgs, T=T_recal)
    for t in range(n_trials_fpr):
        idx = rng.integers(0, len(pool_imgs), size=WINDOW)
        out = eval_window(s1_pool[idx], s2_pool[idx], s2emb_pool[idx])
        for m in methods:
            results_fpr["control"][m].append(out[m]["flag"])
        out_r = eval_window(s1_pool_recal[idx], s2_pool[idx], s2emb_pool[idx])
        for m in methods:
            results_fpr["recalibration"][m].append(out_r[m]["flag"])
    print(f"  control FPR: { {m: round(float(np.mean(v)),3) for m,v in results_fpr['control'].items()} }")
    print(f"  recal FPR:   { {m: round(float(np.mean(v)),3) for m,v in results_fpr['recalibration'].items()} }")
    print(f"  [{time.time()-t0:.1f}s]")

    # ---- Scenario C: real cross-domain shift detection (Photo -> Art/Cartoon/Sketch) ----
    print("Running real cross-domain shift-detection trials...")
    n_trials_shift = 80
    results_shift = {}
    for domain, dd in other_domains.items():
        flags_control, flags_shift = {m: [] for m in methods}, {m: [] for m in methods}
        for t in range(n_trials_shift):
            idx_p = rng.integers(0, len(pool_imgs), size=WINDOW)
            out_c = eval_window(s1_pool[idx_p], s2_pool[idx_p], s2emb_pool[idx_p])
            for m in methods:
                flags_control[m].append(out_c[m]["flag"])
            # genuine cross-domain contamination: mix real other-domain images in
            mask = rng.random(WINDOW) < 0.4
            idx_d = rng.integers(0, dd["n"], size=WINDOW)
            s1w = s1_pool[idx_p].copy(); s1w[mask] = dd["s1"][idx_d][mask]
            s2w = s2_pool[idx_p].copy(); s2w[mask] = dd["s2"][idx_d][mask]
            s2embw = s2emb_pool[idx_p].copy(); s2embw[mask] = dd["s2emb"][idx_d][mask]
            out_s = eval_window(s1w, s2w, s2embw)
            for m in methods:
                flags_shift[m].append(out_s[m]["flag"])
        results_shift[domain] = {
            "control_rate": {m: float(np.mean(flags_control[m])) for m in methods},
            "shift_rate": {m: float(np.mean(flags_shift[m])) for m in methods},
            "gap": {m: float(np.mean(flags_shift[m]) - np.mean(flags_control[m])) for m in methods},
        }
        print(f"  {domain}: gap = {results_shift[domain]['gap']}")

    out = {
        "clean_acc": {"train": float((preds_train == train_labels).mean()),
                      "calib": float((preds_calib == calib_labels).mean()),
                      "pool": float((preds_pool == pool_labels).mean())},
        "domain_acc": {d: other_domains[d]["acc"] for d in other_domains},
        "fpr": results_fpr,
        "cross_domain_shift": results_shift,
        "n_train": len(train_imgs), "n_calib": len(calib_imgs), "n_pool": len(pool_imgs),
        "window": WINDOW, "model": "CLIP ViT-B/32 (LAION-400M, OpenCLIP)",
    }
    json.dump(out, open("/home/claude/paper/results/clip_pacs_results.json", "w"), indent=2)
    print(f"saved. total time {time.time()-t0:.1f}s")


if __name__ == "__main__":
    main()
