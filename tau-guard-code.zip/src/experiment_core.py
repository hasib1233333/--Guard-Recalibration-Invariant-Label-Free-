import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from scipy.special import softmax

from data_loaders import load_dataset
from method import (
    predictive_entropy, MahalanobisNoveltyScorer, kendall_tau,
    calibrate_tau_guard, tau_guard_test,
    calibrate_ks_baseline, ks_baseline_test,
    calibrate_psi_baseline, psi_baseline_test,
    calibrate_mmd_baseline, mmd_baseline_test,
    fit_studd_student, calibrate_studd_baseline, studd_baseline_test,
    calibrate_d3_baseline, d3_baseline_test,
)

ALPHA = 0.05
N_BOOTSTRAP = 2000

CLASSIFIERS = {
    "logreg": lambda: LogisticRegression(max_iter=2000, C=1.0),
    "rf": lambda: RandomForestClassifier(n_estimators=200, max_depth=8, random_state=0),
    "svm": lambda: SVC(probability=True, kernel="rbf", C=1.0, gamma="scale"),
}

STUDENT_CTORS = {
    "logreg": lambda: LogisticRegression(max_iter=1000),
    "rf": lambda: RandomForestClassifier(n_estimators=50, max_depth=5, random_state=1),
    "svm": lambda: LogisticRegression(max_iter=1000),  # cheap surrogate student for SVM teacher
}


def dataset_split_config(n_total):
    """Adaptive split/window sizing so the calibration set is always
    comfortably (>=8x) larger than the monitoring window, avoiding the
    finite-sample bootstrap bias documented in the main study."""
    if n_total < 700:
        return dict(test_size_1=0.55, test_size_2=0.45, window=10)
    else:
        return dict(test_size_1=0.65, test_size_2=0.46, window=20)


def temp_scaled_entropy(clf, X, T):
    from sklearn.linear_model import LogisticRegression
    if isinstance(clf, LogisticRegression):
        # decision_function is the true pre-softmax logit for LogisticRegression.
        z = clf.decision_function(X)
        if z.ndim == 1:
            z = np.stack([-z / 2, z / 2], axis=1)
    else:
        # For SVC (Platt-scaled probabilities) and RandomForest (vote
        # fractions), decision_function/predict_proba is not a softmax of
        # a linear logit, so we recalibrate via log-probability instead,
        # which is the standard generalized-logit surrogate used when the
        # true pre-softmax logit is unavailable.
        proba = np.clip(clf.predict_proba(X), 1e-9, 1 - 1e-9)
        z = np.log(proba)
    proba_T = softmax(z / T, axis=1)
    return predictive_entropy(proba_T)


def prepare_dataset(name, clf_name, rng):
    X, y = load_dataset(name)
    cfg = dataset_split_config(X.shape[0])
    X_train, X_rest, y_train, y_rest = train_test_split(
        X, y, test_size=cfg["test_size_1"], random_state=int(rng.integers(1e6)), stratify=y)
    X_calib, X_pool, y_calib, y_pool = train_test_split(
        X_rest, y_rest, test_size=cfg["test_size_2"], random_state=int(rng.integers(1e6)), stratify=y_rest)

    scaler = StandardScaler().fit(X_train)
    X_train_s = scaler.transform(X_train)
    X_calib_s = scaler.transform(X_calib)
    X_pool_s = scaler.transform(X_pool)

    n_comp = min(10, X_train_s.shape[1], X_train_s.shape[0] - 1)
    pca = PCA(n_components=n_comp, random_state=0).fit(X_train_s)
    Z_train = pca.transform(X_train_s)
    Z_calib = pca.transform(X_calib_s)
    Z_pool = pca.transform(X_pool_s)

    clf = CLASSIFIERS[clf_name]()
    clf.fit(X_train_s, y_train)

    novelty = MahalanobisNoveltyScorer(shrinkage=1e-2).fit(Z_train, y_train)

    student = fit_studd_student(X_train_s, clf, STUDENT_CTORS[clf_name])

    s1_calib = predictive_entropy(clf.predict_proba(X_calib_s))
    s2_calib = novelty.score(Z_calib)

    return {
        "name": name, "clf_name": clf_name, "window": cfg["window"],
        "scaler": scaler, "pca": pca, "clf": clf, "novelty": novelty, "student": student,
        "X_train_s": X_train_s, "y_train": y_train,
        "X_calib_s": X_calib_s, "Z_calib": Z_calib, "s1_calib": s1_calib, "s2_calib": s2_calib,
        "X_pool_s": X_pool_s, "Z_pool": Z_pool, "y_pool": y_pool,
        "n_features": X_train_s.shape[1],
    }


def calibrate_all_methods(ds, rng, methods=("tau_guard", "ks", "psi", "mmd", "studd", "d3")):
    W = ds["window"]
    calib = {}
    if "tau_guard" in methods:
        calib["tau_guard"] = calibrate_tau_guard(ds["s1_calib"], ds["s2_calib"], W, N_BOOTSTRAP, ALPHA,
                                                  rng=np.random.default_rng(int(rng.integers(1e6))))
    if "ks" in methods:
        calib["ks"] = calibrate_ks_baseline(ds["s1_calib"], W, N_BOOTSTRAP, ALPHA,
                                             rng=np.random.default_rng(int(rng.integers(1e6))))
    if "psi" in methods:
        calib["psi"] = calibrate_psi_baseline(ds["s1_calib"], W, N_BOOTSTRAP, ALPHA,
                                               rng=np.random.default_rng(int(rng.integers(1e6))))
    if "mmd" in methods:
        calib["mmd"] = calibrate_mmd_baseline(ds["Z_calib"], W, N_BOOTSTRAP, ALPHA,
                                               rng=np.random.default_rng(int(rng.integers(1e6))))
    if "studd" in methods:
        calib["studd"] = calibrate_studd_baseline(ds["X_calib_s"], ds["clf"], ds["student"], W, N_BOOTSTRAP, ALPHA,
                                                    rng=np.random.default_rng(int(rng.integers(1e6))))
    if "d3" in methods:
        calib["d3"] = calibrate_d3_baseline(ds["X_calib_s"], W, min(N_BOOTSTRAP, 400), ALPHA,
                                             rng=np.random.default_rng(int(rng.integers(1e6))))
    return calib


def sample_window(ds, rng, idx=None):
    n = ds["X_pool_s"].shape[0]
    if idx is None:
        idx = rng.integers(0, n, size=ds["window"])
    return ds["X_pool_s"][idx], ds["Z_pool"][idx], idx


def eval_window(ds, calib, X_win, Z_win, s1_override=None, rng=None):
    out = {}
    s1 = s1_override if s1_override is not None else predictive_entropy(ds["clf"].predict_proba(X_win))
    s2 = ds["novelty"].score(Z_win)
    if "tau_guard" in calib:
        out["tau_guard"] = tau_guard_test(s1, s2, calib["tau_guard"])
    if "ks" in calib:
        out["ks"] = ks_baseline_test(s1, calib["ks"])
    if "psi" in calib:
        out["psi"] = psi_baseline_test(s1, calib["psi"])
    if "mmd" in calib:
        out["mmd"] = mmd_baseline_test(Z_win, calib["mmd"])
    if "studd" in calib:
        out["studd"] = studd_baseline_test(X_win, ds["clf"], ds["student"], calib["studd"])
    if "d3" in calib:
        out["d3"] = d3_baseline_test(X_win, calib["d3"], rng=rng or np.random.default_rng())
    return out
