"""
Sequential (CUSUM) extension of tau-Guard: compares the paper's default
per-window thresholding against a two-sided CUSUM chart applied to the
standardized statistic Z_t = (tau_hat_t - tau0)/sigma0, in terms of
Average Run Length under H0 (ARL0) and average detection delay under
genuine shift -- the streaming-native metrics a sequential-monitoring
reviewer would expect alongside fixed-window flag rates.
"""
import numpy as np
from ablation import prepare_base
from method import predictive_entropy, MahalanobisNoveltyScorer, calibrate_tau_guard, kendall_tau
from scenarios import sample_pca_aligned_direction


def compute_z_sequence(base, calib, scorer, n_windows, W, rng, shift_onset=None,
                        shift_sigma=6.0, contamination_frac=0.45):
    """Generate a sequence of standardized Z_t values. If shift_onset is
    given, injects a genuine shift starting at that window index."""
    Z_seq = []
    direction = None
    for w in range(n_windows):
        idx = rng.integers(0, base["X_pool_s"].shape[0], size=W)
        Xw = base["X_pool_s"][idx].copy()
        if shift_onset is not None and w >= shift_onset:
            if direction is None:
                direction_ds = {"pca": base["pca"], "novelty": scorer}
                direction = sample_pca_aligned_direction(direction_ds, rng, magnitude=shift_sigma)
            mask = rng.random(W) < contamination_frac
            Xw[mask] += direction[None, :]
        Zw = base["pca"].transform(Xw)
        s1 = predictive_entropy(base["clf"].predict_proba(Xw))
        s2 = scorer.score(Zw)
        tau_hat = kendall_tau(s1, s2)
        z = (tau_hat - calib["tau0"]) / (calib["sigma0"] + 1e-12)
        Z_seq.append(z)
    return np.array(Z_seq)


def cusum_run(Z_seq, k, h):
    """Two-sided CUSUM. Returns the index of first alarm (or None) and the
    full (Splus, Sminus) trajectories."""
    Splus, Sminus = 0.0, 0.0
    for t, z in enumerate(Z_seq):
        Splus = max(0.0, Splus + z - k)
        Sminus = max(0.0, Sminus - z - k)
        if Splus > h or Sminus > h:
            return t, Splus, Sminus
    return None, Splus, Sminus


def calibrate_cusum_threshold(base, calib, scorer, W, rng, k=0.5, target_arl0=20,
                                n_bootstrap_sequences=60, max_len=60):
    """Bootstrap-calibrate the CUSUM decision threshold h to achieve a
    target Average Run Length under H0 (ARL0), matching the per-window
    test's own nominal false-alarm rate (ARL0 = 1/alpha = 20 at alpha=0.05)."""
    # binary search over h
    lo, hi = 0.1, 30.0
    for _ in range(12):
        h = (lo + hi) / 2
        run_lengths = []
        for _ in range(n_bootstrap_sequences):
            Z_seq = compute_z_sequence(base, calib, scorer, max_len, W, rng)
            t_alarm, _, _ = cusum_run(Z_seq, k, h)
            run_lengths.append(t_alarm if t_alarm is not None else max_len)
        arl0 = np.mean(run_lengths)
        if arl0 < target_arl0:
            lo = h  # raise threshold to increase ARL0
        else:
            hi = h
    return h, arl0


def main():
    rng = np.random.default_rng(123)
    base = prepare_base("synthetic", seed=1)
    W = 20
    Z_train = base["pca"].transform(base["X_train_s"])
    scorer = MahalanobisNoveltyScorer(shrinkage=1e-2).fit(Z_train, base["y_train"])
    s1_calib = predictive_entropy(base["clf"].predict_proba(base["X_calib_s"]))
    s2_calib = scorer.score(base["Z_calib"])
    calib = calibrate_tau_guard(s1_calib, s2_calib, W, 1500, 0.05, rng=np.random.default_rng(1))

    print("Calibrating CUSUM threshold h for target ARL0=20 (k=0.5)...")
    k = 0.5
    h, achieved_arl0 = calibrate_cusum_threshold(base, calib, scorer, W, rng, k=k, target_arl0=20)
    print(f"  calibrated h={h:.3f}, achieved ARL0={achieved_arl0:.1f} (target 20)")

    # Validate ARL0 on a fresh, independent set of H0 sequences
    print("Validating ARL0 on fresh H0 sequences...")
    run_lengths = []
    for _ in range(300):
        Z_seq = compute_z_sequence(base, calib, scorer, 200, W, rng)
        t_alarm, _, _ = cusum_run(Z_seq, k, h)
        run_lengths.append(t_alarm if t_alarm is not None else 200)
    print(f"  validated ARL0 = {np.mean(run_lengths):.1f} (per-window test's ARL0 = 1/alpha = {1/0.05:.1f})")

    # Compare detection delay: per-window thresholding vs CUSUM, under
    # genuine shift (same recipe as the main shift-detection experiments)
    print("Comparing detection delay under genuine shift (onset at window 5)...")
    onset = 5
    n_windows = 30
    n_trials = 150
    from method import tau_guard_test
    perwindow_delays, cusum_delays = [], []
    perwindow_detected, cusum_detected = 0, 0
    for trial in range(n_trials):
        Z_seq = compute_z_sequence(base, calib, scorer, n_windows, W, rng, shift_onset=onset)
        # per-window: reconstruct flags from Z_seq using calib lo/hi on raw tau
        # (recompute tau_hat from z: tau_hat = z*sigma0+tau0)
        tau_hats = Z_seq * calib["sigma0"] + calib["tau0"]
        flags = (tau_hats < calib["lo"]) | (tau_hats > calib["hi"])
        post_flags = np.where(flags[onset:])[0]
        if len(post_flags) > 0:
            perwindow_delays.append(int(post_flags[0]))
            perwindow_detected += 1
        # CUSUM: run cumulatively; alarm time relative to onset
        t_alarm, _, _ = cusum_run(Z_seq, k, h)
        if t_alarm is not None and t_alarm >= onset:
            cusum_delays.append(t_alarm - onset)
            cusum_detected += 1

    print(f"  Per-window: detection rate={perwindow_detected/n_trials:.3f}, "
          f"mean delay={np.mean(perwindow_delays) if perwindow_delays else float('nan'):.2f} windows")
    print(f"  CUSUM:      detection rate={cusum_detected/n_trials:.3f}, "
          f"mean delay={np.mean(cusum_delays) if cusum_delays else float('nan'):.2f} windows")

    import json
    out = {
        "cusum_k": k, "cusum_h": h, "target_arl0": 20, "validated_arl0": float(np.mean(run_lengths)),
        "perwindow_arl0_theoretical": 1 / 0.05,
        "perwindow_detect_rate": perwindow_detected / n_trials,
        "perwindow_mean_delay": float(np.mean(perwindow_delays)) if perwindow_delays else None,
        "cusum_detect_rate": cusum_detected / n_trials,
        "cusum_mean_delay": float(np.mean(cusum_delays)) if cusum_delays else None,
        "n_trials": n_trials, "onset": onset, "n_windows": n_windows,
    }
    json.dump(out, open("/home/claude/paper/results/cusum_results.json", "w"), indent=2)
    print("saved.")


if __name__ == "__main__":
    main()
