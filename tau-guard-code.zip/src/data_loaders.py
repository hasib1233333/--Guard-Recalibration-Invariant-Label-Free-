import numpy as np
import pandas as pd
from sklearn.datasets import load_breast_cancer, load_digits, load_wine, make_classification

DATA_DIR = "/home/claude/paper/data"


def load_dataset(name):
    if name == "breast_cancer":
        d = load_breast_cancer()
        return d.data, d.target
    elif name == "digits":
        d = load_digits()
        return d.data, d.target
    elif name == "wine":
        d = load_wine()
        return d.data, d.target
    elif name == "synthetic":
        X, y = make_classification(
            n_samples=1500, n_features=20, n_informative=8, n_redundant=4,
            n_classes=4, n_clusters_per_class=2, class_sep=1.2,
            flip_y=0.03, random_state=7)
        return X, y
    elif name == "diabetes":
        df = pd.read_csv(f"{DATA_DIR}/diabetes.csv", header=None)
        X = df.iloc[:, :-1].values.astype(float)
        y = df.iloc[:, -1].values.astype(int)
        return X, y
    elif name == "ionosphere":
        df = pd.read_csv(f"{DATA_DIR}/ionosphere.csv", header=None)
        X = df.iloc[:, :-1].values.astype(float)
        y = (df.iloc[:, -1].values == "g").astype(int)
        return X, y
    elif name == "sonar":
        df = pd.read_csv(f"{DATA_DIR}/sonar.csv", header=None)
        X = df.iloc[:, :-1].values.astype(float)
        y = (df.iloc[:, -1].values == "R").astype(int)
        return X, y
    elif name == "banknote":
        df = pd.read_csv(f"{DATA_DIR}/banknote.csv", header=None)
        X = df.iloc[:, :-1].values.astype(float)
        y = df.iloc[:, -1].values.astype(int)
        return X, y
    else:
        raise ValueError(name)


DATASET_INFO = {
    "breast_cancer": ("Medical (tabular)", 569, 30, 2, "real (UCI/sklearn)"),
    "digits": ("Image (8x8 pixel)", 1797, 64, 10, "real (UCI/sklearn)"),
    "synthetic": ("Synthetic (controlled)", 1500, 20, 4, "synthetic"),
    "wine": ("Chemical (tabular)", 178, 13, 3, "real (UCI/sklearn)"),
    "diabetes": ("Medical (tabular)", 768, 8, 2, "real (UCI)"),
    "ionosphere": ("Radar signal", 351, 34, 2, "real (UCI)"),
    "sonar": ("Sonar signal", 208, 60, 2, "real (UCI)"),
    "banknote": ("Image-derived (wavelet)", 1372, 4, 2, "real (UCI)"),
}

if __name__ == "__main__":
    for name in DATASET_INFO:
        X, y = load_dataset(name)
        print(name, X.shape, "classes:", len(np.unique(y)), "matches info:", DATASET_INFO[name][1] == X.shape[0])
