import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 300})

R = "/home/claude/paper/results/"
FIGDIR = "/home/claude/paper/figures/"
METHODS = ["tau_guard", "ks", "psi", "mmd", "studd", "d3"]
LABELS = {"tau_guard": r"$\tau$-Guard", "ks": "Conf-KS", "psi": "PSI", "mmd": "MMD", "studd": "STUDD", "d3": "D3"}
COLORS = {"tau_guard": "#1b6ca8", "ks": "#d9534f", "psi": "#f0ad4e", "mmd": "#5cb85c", "studd": "#9467bd", "d3": "#8c564b"}

summary = json.load(open(R + "analysis_v2_summary.json"))

# ------------------------------------------------------------------
# Fig: FPR comparison, 6 methods, 3 core datasets (control vs recal)
# ------------------------------------------------------------------
core_per_ds = summary["core_fpr"]["per_dataset"]
datasets = ["breast_cancer", "synthetic", "digits"]
ds_labels = ["Breast Cancer", "Synthetic", "Digits"]
fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.5), sharey=True)
x = np.arange(len(METHODS)); width = 0.35
for ax, ds, dl in zip(axes, datasets, ds_labels):
    ctrl = [core_per_ds[ds][m]["control_fpr"] for m in METHODS]
    recal = [core_per_ds[ds][m]["recal_fpr"] for m in METHODS]
    ax.bar(x - width/2, ctrl, width, label="Control", color="#9ecae1", edgecolor="black", linewidth=0.4)
    ax.bar(x + width/2, recal, width, label="Recalibrated", color="#08306b", edgecolor="black", linewidth=0.4)
    ax.axhline(0.05, color="gray", linestyle="--", linewidth=0.8)
    ax.set_xticks(x); ax.set_xticklabels([LABELS[m] for m in METHODS], rotation=40, ha="right", fontsize=7)
    ax.set_title(dl, fontsize=9); ax.set_ylim(0, 1.05)
axes[0].set_ylabel("False-positive rate")
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, loc="upper center", ncol=2, bbox_to_anchor=(0.5, 1.12), frameon=False, fontsize=8)
fig.tight_layout()
fig.savefig(FIGDIR + "fig_fpr_6method.pdf", bbox_inches="tight")
plt.close(fig)
print("saved fig_fpr_6method.pdf")

# ------------------------------------------------------------------
# Fig: shift detection gap, 6 methods, core datasets, shift+recal scenario
# ------------------------------------------------------------------
core_shift = summary["core_shift"]
fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.5), sharey=True)
for ax, ds, dl in zip(axes, datasets, ds_labels):
    gaps = [core_shift[ds]["shift_plus_recal"].get(m, {}).get("gap", 0) for m in METHODS]
    colors = [COLORS[m] for m in METHODS]
    ax.bar(x, gaps, color=colors, edgecolor="black", linewidth=0.4)
    ax.axhline(0, color="gray", linewidth=0.8)
    ax.set_xticks(x); ax.set_xticklabels([LABELS[m] for m in METHODS], rotation=40, ha="right", fontsize=7)
    ax.set_title(dl, fontsize=9)
axes[0].set_ylabel("Post$-$pre onset\nflag-rate gap")
fig.tight_layout()
fig.savefig(FIGDIR + "fig_shift_gap_6method.pdf", bbox_inches="tight")
plt.close(fig)
print("saved fig_shift_gap_6method.pdf")

# ------------------------------------------------------------------
# Fig: classifier generality (control vs recal FPR for tau-Guard, KS, PSI
# across logreg/RF/SVM)
# ------------------------------------------------------------------
clf_gen = summary["classifier_generality"]
clfs = ["logreg", "rf", "svm"]
clf_labels = ["LogReg", "Random Forest", "SVM"]
fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.5), sharey=True)
show_methods = ["tau_guard", "ks", "psi"]
xg = np.arange(len(show_methods))
for ax, clf_name, cl in zip(axes, clfs, clf_labels):
    ctrl = [clf_gen[clf_name][m]["control_fpr"] for m in show_methods]
    recal = [clf_gen[clf_name][m]["recal_fpr"] for m in show_methods]
    ax.bar(xg - width/2, ctrl, width, label="Control", color="#9ecae1", edgecolor="black", linewidth=0.4)
    ax.bar(xg + width/2, recal, width, label="Recalibrated", color="#08306b", edgecolor="black", linewidth=0.4)
    ax.set_xticks(xg); ax.set_xticklabels([LABELS[m] for m in show_methods], fontsize=8)
    ax.set_title(cl, fontsize=9); ax.set_ylim(0, 1.05)
axes[0].set_ylabel("False-positive rate")
h, l = axes[0].get_legend_handles_labels()
fig.legend(h, l, loc="upper center", ncol=2, bbox_to_anchor=(0.5, 1.12), frameon=False, fontsize=8)
fig.tight_layout()
fig.savefig(FIGDIR + "fig_classifier_generality.pdf", bbox_inches="tight")
plt.close(fig)
print("saved fig_classifier_generality.pdf")

# ------------------------------------------------------------------
# Fig: ablation + sensitivity combined panel (4 subplots)
# ------------------------------------------------------------------
ablation = json.load(open(R + "ablation_results.json"))
sensitivity = json.load(open(R + "sensitivity_results.json"))

fig, axes = plt.subplots(1, 4, figsize=(9.5, 2.3))

ws = ablation["window_size"]
windows = sorted([int(k) for k in ws.keys()])
fprs = [ws[str(w)]["control_fpr"] for w in windows]
ratios = [ws[str(w)]["ratio"] for w in windows]
ax = axes[0]
ax.plot(windows, fprs, "o-", color=COLORS["tau_guard"])
ax.axhline(0.05, color="gray", linestyle="--", linewidth=0.8)
ax.set_xlabel("Window size $n$"); ax.set_ylabel("Control FPR"); ax.set_title("(a) Window size", fontsize=8)
for wv, r, f in zip(windows, ratios, fprs):
    ax.annotate(f"{r:.0f}x", (wv, f), fontsize=6, textcoords="offset points", xytext=(0, 5))

bs = sensitivity["calib_ratio"]
ratios2 = sorted([int(k) for k in bs.keys()])
fprs2 = [bs[str(r)]["empirical_fpr"] for r in ratios2]
ax = axes[1]
ax.plot(ratios2, fprs2, "o-", color=COLORS["tau_guard"])
ax.axhline(0.05, color="gray", linestyle="--", linewidth=0.8)
ax.axvspan(0, 3, color="red", alpha=0.08)
ax.set_xlabel("Calib. size / window size"); ax.set_title("(b) Calib.-set ratio", fontsize=8)

temp = sensitivity["temperature"]
temps = sorted([float(k) for k in temp.keys()])
fprs3 = [temp[str(t) if str(t) in temp else t]["fpr"] if str(t) in temp else temp[t]["fpr"] for t in temps]
# handle key type consistency
fprs3 = []
for t in temps:
    key = t if t in temp else str(t)
    if key not in temp:
        key = [k for k in temp if float(k) == t][0]
    fprs3.append(temp[key]["fpr"])
ax = axes[2]
ax.plot(temps, fprs3, "o-", color=COLORS["tau_guard"])
ax.axhline(0.05, color="gray", linestyle="--", linewidth=0.8)
ax.set_xlabel("Temperature $T$"); ax.set_title("(c) Temperature", fontsize=8)

nov = ablation["novelty_score"]
names = list(nov.keys())
ctrl_n = [nov[n]["control_fpr"] for n in names]
shift_n = [nov[n]["shift_flag_rate"] for n in names]
ax = axes[3]
xN = np.arange(len(names))
ax.bar(xN - 0.2, ctrl_n, 0.4, label="Control FPR", color="#9ecae1", edgecolor="black", linewidth=0.4)
ax.bar(xN + 0.2, shift_n, 0.4, label="Shift flag rate", color="#08306b", edgecolor="black", linewidth=0.4)
ax.set_xticks(xN); ax.set_xticklabels(names, rotation=30, ha="right", fontsize=7)
ax.set_title("(d) Novelty score", fontsize=8)
ax.legend(fontsize=6, frameon=False)

for ax in axes:
    ax.tick_params(labelsize=7)
fig.tight_layout()
fig.savefig(FIGDIR + "fig_ablation_sensitivity.pdf", bbox_inches="tight")
plt.close(fig)
print("saved fig_ablation_sensitivity.pdf")

# ------------------------------------------------------------------
# Fig: runtime / complexity comparison
# ------------------------------------------------------------------
runtime = json.load(open(R + "runtime_benchmark.json"))
fig, axes = plt.subplots(1, 2, figsize=(6.5, 2.6))
ds_for_runtime = "digits"
times = [runtime[ds_for_runtime]["per_window_time_ms"][m] for m in METHODS]
storage = [runtime[ds_for_runtime]["storage_bytes"][m] / 1024 for m in METHODS]
colors = [COLORS[m] for m in METHODS]

ax = axes[0]
ax.bar(range(len(METHODS)), times, color=colors, edgecolor="black", linewidth=0.4)
ax.set_yscale("log")
ax.set_xticks(range(len(METHODS))); ax.set_xticklabels([LABELS[m] for m in METHODS], rotation=40, ha="right", fontsize=7)
ax.set_ylabel("Per-window time (ms, log scale)"); ax.set_title("(a) Inference latency", fontsize=8)

ax = axes[1]
ax.bar(range(len(METHODS)), storage, color=colors, edgecolor="black", linewidth=0.4)
ax.set_yscale("log")
ax.set_xticks(range(len(METHODS))); ax.set_xticklabels([LABELS[m] for m in METHODS], rotation=40, ha="right", fontsize=7)
ax.set_ylabel("Stored state (KB, log scale)"); ax.set_title("(b) Storage footprint", fontsize=8)
fig.tight_layout()
fig.savefig(FIGDIR + "fig_runtime_complexity.pdf", bbox_inches="tight")
plt.close(fig)
print("saved fig_runtime_complexity.pdf")

# ------------------------------------------------------------------
# Fig: real-world electricity case study
# ------------------------------------------------------------------
elec = json.load(open(R + "electricity_case_study.json"))
recs = elec["records"]
w_idx = [r["window"] for r in recs]
accs = [r["acc"] for r in recs]
tg_flags = [r["tau_guard"] for r in recs]
ks_flags = [r["ks"] for r in recs]

fig, axes = plt.subplots(3, 1, figsize=(7, 3.6), sharex=True,
                          gridspec_kw={"height_ratios": [2, 0.6, 0.6]})
axes[0].plot(w_idx, accs, color="black", linewidth=0.6)
axes[0].axhline(0.5, color="gray", linestyle=":", linewidth=0.7)
axes[0].set_ylabel("Classifier\naccuracy"); axes[0].set_title("Electricity (real-world) stream: accuracy and alarms over time", fontsize=9)

axes[1].fill_between(w_idx, 0, tg_flags, step="pre", color=COLORS["tau_guard"], alpha=0.8)
axes[1].set_ylabel(r"$\tau$-Guard", fontsize=7); axes[1].set_yticks([])

axes[2].fill_between(w_idx, 0, ks_flags, step="pre", color=COLORS["ks"], alpha=0.8)
axes[2].set_ylabel("Conf-KS", fontsize=7); axes[2].set_yticks([])
axes[2].set_xlabel("Window index (chronological, 48 readings/window)")

for ax in axes:
    ax.tick_params(labelsize=7)
fig.tight_layout()
fig.savefig(FIGDIR + "fig_electricity_case_study.pdf", bbox_inches="tight")
plt.close(fig)
print("saved fig_electricity_case_study.pdf")

print("all figures done.")
