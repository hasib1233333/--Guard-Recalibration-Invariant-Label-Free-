"""
Extract real deep-vision features (softmax entropy + penultimate-layer
embeddings) from genuine pretrained CIFAR-10 classifiers (ResNet-20 and
RepVGG-A0), under real CIFAR-10-C-style corruptions, for the deep-vision
extension study.
"""
import sys
sys.path.insert(0, "/home/claude/pytorch-cifar-models")
import glob
import numpy as np
import torch
from PIL import Image, ImageFilter
from pytorch_cifar_models.resnet import cifar10_resnet20
from pytorch_cifar_models.repvgg import cifar10_repvgg_a0

CLASSES = ['airplane', 'automobile', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck']
MEAN = torch.tensor([0.4914, 0.4822, 0.4465]).view(1, 3, 1, 1)
STD = torch.tensor([0.2470, 0.2435, 0.2616]).view(1, 3, 1, 1)
DATA_ROOT = "/home/claude/CIFAR-10-images"

_models = {}

ARCHS = {
    "resnet20": {"ctor": cifar10_resnet20, "weights": "/home/claude/cifar10_resnet20.pt",
                  "embed_dim": 64, "embed_module": "avgpool"},
    "repvgg_a0": {"ctor": cifar10_repvgg_a0, "weights": "/home/claude/cifar10_repvgg_a0.pt",
                   "embed_dim": 1280, "embed_module": "gap"},
}


def get_model(arch="resnet20"):
    if arch not in _models:
        spec = ARCHS[arch]
        m = spec["ctor"](pretrained=False)
        sd = torch.load(spec["weights"], map_location="cpu")
        m.load_state_dict(sd)
        m.eval()
        _models[arch] = m
    return _models[arch]


def load_images(split, n_per_class, seed=0, offset=0):
    """Load n_per_class real images per class from the given split
    ('train' or 'test'), returning (images as list of PIL, labels).
    Images are shuffled across classes after loading: downstream code
    (e.g. the MMD baseline, which truncates a larger reference array to
    match a smaller window rather than randomly subsampling it) assumes
    the array order carries no class structure, exactly as sklearn's
    train_test_split already guarantees for the tabular experiments."""
    rng = np.random.default_rng(seed)
    imgs, labels = [], []
    for ci, cls in enumerate(CLASSES):
        files = sorted(glob.glob(f"{DATA_ROOT}/{split}/{cls}/*.jpg"))
        idx = rng.choice(len(files), size=min(n_per_class, len(files) - offset), replace=False) + offset
        idx = idx[idx < len(files)]
        for i in idx:
            imgs.append(Image.open(files[i]).convert("RGB"))
            labels.append(ci)
    labels = np.array(labels)
    perm = rng.permutation(len(imgs))
    imgs = [imgs[i] for i in perm]
    labels = labels[perm]
    return imgs, labels


# ------------------------------------------------------------------
# Real CIFAR-10-C-style corruption functions (Hendrycks & Dietterich 2019
# define these; we implement the core, well-known ones directly with
# PIL/numpy rather than depending on an external package, at a chosen
# severity level).
# ------------------------------------------------------------------

def corrupt_gaussian_noise(img, severity=3):
    arr = np.array(img).astype(np.float32) / 255.0
    sigma = [0.04, 0.06, 0.08, 0.10, 0.14][severity - 1]
    rng = np.random.default_rng(abs(hash(img.tobytes())) % (2**32))
    noisy = arr + rng.normal(0, sigma, arr.shape)
    return Image.fromarray((np.clip(noisy, 0, 1) * 255).astype(np.uint8))


def corrupt_motion_blur(img, severity=3):
    radius = [0.5, 1.0, 1.5, 2.0, 2.5][severity - 1]
    return img.filter(ImageFilter.GaussianBlur(radius=radius * 2))


def corrupt_brightness(img, severity=3):
    arr = np.array(img).astype(np.float32) / 255.0
    delta = [0.1, 0.2, 0.3, 0.4, 0.5][severity - 1]
    bright = arr + delta
    return Image.fromarray((np.clip(bright, 0, 1) * 255).astype(np.uint8))


def corrupt_contrast(img, severity=3):
    arr = np.array(img).astype(np.float32) / 255.0
    factor = [0.75, 0.6, 0.45, 0.3, 0.15][severity - 1]
    mean = arr.mean(axis=(0, 1), keepdims=True)
    contrasted = (arr - mean) * factor + mean
    return Image.fromarray((np.clip(contrasted, 0, 1) * 255).astype(np.uint8))


CORRUPTIONS = {
    "gaussian_noise": corrupt_gaussian_noise,
    "motion_blur": corrupt_motion_blur,
    "brightness": corrupt_brightness,
    "contrast": corrupt_contrast,
}


def extract_features(images, arch="resnet20", batch_size=64):
    """Return (entropy s1 [n], embedding s2_input [n,embed_dim], predicted_label [n])."""
    model = get_model(arch)
    embed_module = getattr(model, ARCHS[arch]["embed_module"])
    entropies, embeddings, preds = [], [], []

    def hook(module, inp, out):
        embeddings.append(out.detach().reshape(out.shape[0], -1).numpy())

    h = embed_module.register_forward_hook(hook)
    with torch.no_grad():
        for i in range(0, len(images), batch_size):
            batch = images[i:i + batch_size]
            arrs = np.stack([np.array(im).astype(np.float32) / 255.0 for im in batch])
            t = torch.tensor(arrs).permute(0, 3, 1, 2)
            t = (t - MEAN) / STD
            logits = model(t)
            proba = torch.softmax(logits, dim=1).numpy()
            ent = -np.sum(np.clip(proba, 1e-12, 1) * np.log(np.clip(proba, 1e-12, 1)), axis=1)
            entropies.append(ent)
            preds.append(proba.argmax(axis=1))
    h.remove()
    return np.concatenate(entropies), np.concatenate(embeddings), np.concatenate(preds)


def temp_scaled_entropy_from_images(images, T, arch="resnet20", batch_size=64):
    model = get_model(arch)
    entropies = []
    with torch.no_grad():
        for i in range(0, len(images), batch_size):
            batch = images[i:i + batch_size]
            arrs = np.stack([np.array(im).astype(np.float32) / 255.0 for im in batch])
            t = torch.tensor(arrs).permute(0, 3, 1, 2)
            t = (t - MEAN) / STD
            logits = model(t)
            proba = torch.softmax(logits / T, dim=1).numpy()
            ent = -np.sum(np.clip(proba, 1e-12, 1) * np.log(np.clip(proba, 1e-12, 1)), axis=1)
            entropies.append(ent)
    return np.concatenate(entropies)


if __name__ == "__main__":
    imgs, labels = load_images("test", 20)
    s1, s2emb, preds = extract_features(imgs)
    acc = (preds == labels).mean()
    print(f"n={len(imgs)} clean accuracy={acc:.3f} entropy mean={s1.mean():.3f} embedding dim={s2emb.shape[1]}")

    imgs_corrupt = [corrupt_gaussian_noise(im, severity=3) for im in imgs]
    s1c, s2embc, predsc = extract_features(imgs_corrupt)
    accc = (predsc == labels).mean()
    print(f"gaussian_noise sev=3: accuracy={accc:.3f} entropy mean={s1c.mean():.3f}")
