import json
import numpy as np
from scipy import stats as spstats
from statsmodels.stats.contingency_tables import mcnemar

R = "/home/claude/paper/results/"
METHODS = ["tau_guard", "ks", "psi", "mmd", "studd", "d3"]
METHOD_NAMES = {"tau_guard": "tau-Guard (ours)", "ks": "Confidence-KS", "psi": "PSI",
                "mmd": "Feature-MMD", "studd": "STUDD", "d3": "D3"}


def wilson_ci(k, n, z=1.96):
    if n == 0:
        return (float("nan"), float("nan"))
    phat = k / n
    denom = 1 + z**2 / n
    center = (phat + z**2 / (2 * n)) / denom
    half = (z * np.sqrt(phat * (1 - phat) / n + z**2 / (4 * n**2))) / denom
    return center - half, center + half


def pooled_fpr_table(results_path, datasets, out_name):
    data = json.load(open(results_path))
    pooled_control = {m: [] for m in METHODS}
    pooled_recal = {m: [] for m in METHODS}
    per_dataset = {ds: {m: {"control": [], "recal": []} for m in METHODS} for ds in datasets}
    for seed in data:
        for ds in datasets:
            fpr = data[seed][ds]["fpr"]
            for m in METHODS:
                pooled_control[m].extend(fpr["control"][m])
                pooled_recal[m].extend(fpr["recalibration"][m])
                per_dataset[ds][m]["control"].extend(fpr["control"][m])
                per_dataset[ds][m]["recal"].extend(fpr["recalibration"][m])

    print(f"\n=== {out_name}: pooled control vs recalibration FPR ===")
    rows = []
    for m in METHODS:
        c = np.array(pooled_control[m]); r = np.array(pooled_recal[m])
        n = len(c)
        fpr_c, fpr_r = float(c.mean()), float(r.mean())
        ci_c, ci_r = wilson_ci(c.sum(), n), wilson_ci(r.sum(), n)
        b = int(np.sum((c == 0) & (r == 1))); cc = int(np.sum((c == 1) & (r == 0)))
        table = [[int(np.sum((c == 1) & (r == 1))), cc], [b, int(np.sum((c == 0) & (r == 0)))]]
        try:
            res = mcnemar(table, exact=(b + cc < 25), correction=True)
            p = res.pvalue
        except Exception:
            p = float("nan")
        rows.append({"method": m, "n": n, "control_fpr": fpr_c, "control_ci": ci_c,
                      "recal_fpr": fpr_r, "recal_ci": ci_r, "mcnemar_p": p})
        print(f"{METHOD_NAMES[m]:20s} n={n:5d} control={fpr_c:.3f} recal={fpr_r:.3f} McNemar p={p:.3g}")

    per_ds_rows = {}
    for ds in datasets:
        per_ds_rows[ds] = {}
        for m in METHODS:
            c = np.array(per_dataset[ds][m]["control"]); r = np.array(per_dataset[ds][m]["recal"])
            per_ds_rows[ds][m] = {"control_fpr": float(c.mean()), "recal_fpr": float(r.mean()), "n": len(c)}
    return {"pooled": rows, "per_dataset": per_ds_rows}


def classifier_generality_table():
    print("\n=== Classifier generality: control vs recal FPR by classifier ===")
    out = {}
    for clf_name in ["logreg", "rf", "svm"]:
        data = json.load(open(f"{R}clf_{clf_name}_results.json"))
        datasets = ["breast_cancer", "digits", "diabetes"]
        pooled_control = {m: [] for m in METHODS}
        pooled_recal = {m: [] for m in METHODS}
        for seed in data:
            for ds in datasets:
                fpr = data[seed][ds]["fpr"]
                for m in METHODS:
                    pooled_control[m].extend(fpr["control"][m])
                    pooled_recal[m].extend(fpr["recalibration"][m])
        out[clf_name] = {}
        for m in METHODS:
            c = np.array(pooled_control[m]); r = np.array(pooled_recal[m])
            out[clf_name][m] = {"control_fpr": float(c.mean()), "recal_fpr": float(r.mean()), "n": len(c)}
            print(f"  {clf_name:8s} {METHOD_NAMES[m]:20s} control={c.mean():.3f} recal={r.mean():.3f}")
    return out


def shift_gap_table(results_path, datasets, out_name):
    data = json.load(open(results_path))
    print(f"\n=== {out_name}: shift detection gap (post-pre onset) ===")
    out = {}
    for ds in datasets:
        out[ds] = {}
        for scen in ["shift_only", "shift_plus_recal"]:
            out[ds][scen] = {}
            for m in METHODS:
                pre_all, post_all = [], []
                for seed in data:
                    if ds not in data[seed] or not data[seed][ds]["shift"]:
                        continue
                    d = data[seed][ds]["shift"][scen][m]
                    pre_all.extend(d["pre_rate"])
                    post_all.extend(d["post_rate"])
                if not pre_all:
                    continue
                pre_all, post_all = np.array(pre_all), np.array(post_all)
                gap = float(post_all.mean() - pre_all.mean())
                out[ds][scen][m] = {"pre": float(pre_all.mean()), "post": float(post_all.mean()), "gap": gap}
        print(f" {ds}: " + ", ".join(f"{m}:{out[ds]['shift_plus_recal'].get(m,{}).get('gap',float('nan')):+.3f}" for m in METHODS))
    return out


if __name__ == "__main__":
    core = pooled_fpr_table(R + "core_6method_results.json", ["breast_cancer", "synthetic", "digits"], "CORE")
    ext = pooled_fpr_table(R + "extended_dataset_results.json",
                            ["wine", "diabetes", "ionosphere", "sonar", "banknote"], "EXTENDED")
    clf = classifier_generality_table()
    shift_core = shift_gap_table(R + "core_6method_results.json", ["breast_cancer", "synthetic", "digits"], "CORE SHIFT")
    shift_ext = shift_gap_table(R + "extended_dataset_results.json",
                                 ["wine", "diabetes", "ionosphere", "sonar", "banknote"], "EXTENDED SHIFT")

    json.dump({"core_fpr": core, "extended_fpr": ext, "classifier_generality": clf,
               "core_shift": shift_core, "extended_shift": shift_ext},
              open(R + "analysis_v2_summary.json", "w"), indent=2)
    print("\nsaved analysis_v2_summary.json")
