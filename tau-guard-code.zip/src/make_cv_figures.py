"""
Computer-vision-specific figures for the Discover Computer Vision alignment:
(1) sample digit images per class (what the classifier actually sees)
(2) genuine covariate shift visualized directly in pixel space (before/after)
(3) 2D embedding scatter of image samples colored by entropy/novelty, with
    the shifted subpopulation highlighted -- makes the abstract "novelty
    score" and "shift" concepts visually concrete for a CV audience.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.datasets import load_digits
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.manifold import TSNE

from method import predictive_entropy, MahalanobisNoveltyScorer

FIGDIR = "/home/claude/paper/figures/"
plt.rcParams.update({"font.size": 9})

d = load_digits()
X_img, X_flat, y = d.images, d.data, d.target

# ------------------------------------------------------------------
# Figure: sample digit images, one per class 0-9
# ------------------------------------------------------------------
fig, axes = plt.subplots(1, 10, figsize=(10, 1.3))
for cls in range(10):
    idx = np.where(y == cls)[0][0]
    ax = axes[cls]
    ax.imshow(X_img[idx], cmap="gray_r")
    ax.set_title(str(cls), fontsize=9)
    ax.set_xticks([]); ax.set_yticks([])
fig.suptitle("Sample inputs: UCI Digits (8$\\times$8 grayscale handwritten digit images)", y=1.15, fontsize=9)
fig.tight_layout()
fig.savefig(FIGDIR + "fig_cv_sample_digits.pdf", bbox_inches="tight")
plt.close(fig)
print("saved fig_cv_sample_digits.pdf")

# ------------------------------------------------------------------
# Prepare classifier/novelty scorer (mirrors the main experiment setup)
# ------------------------------------------------------------------
rng = np.random.default_rng(2024)
X_train, X_rest, y_train, y_rest = train_test_split(X_flat, y, test_size=0.65, random_state=1, stratify=y)
X_calib, X_pool, y_calib, y_pool = train_test_split(X_rest, y_rest, test_size=0.46, random_state=1, stratify=y_rest)

scaler = StandardScaler().fit(X_train)
X_train_s, X_pool_s = scaler.transform(X_train), scaler.transform(X_pool)
pca = PCA(n_components=10, random_state=0).fit(X_train_s)
Z_train, Z_pool = pca.transform(X_train_s), pca.transform(X_pool_s)
clf = LogisticRegression(max_iter=2000).fit(X_train_s, y_train)
novelty = MahalanobisNoveltyScorer(shrinkage=1e-2).fit(Z_train, y_train)

# construct a genuine shift direction (same recipe as the main study:
# mixing the novelty scorer's most Mahalanobis-sensitive direction with a
# random PCA-space direction), then map back to pixel space
eigval, eigvec = np.linalg.eigh(novelty.precision_)
max_sens_dir = eigvec[:, np.argmax(eigval)]
rand_dir = rng.normal(size=10); rand_dir /= np.linalg.norm(rand_dir)
mixed = 0.7 * max_sens_dir + 0.3 * rand_dir
mixed /= np.linalg.norm(mixed)
origin = pca.inverse_transform(np.zeros((1, 10)))
shifted_dir = (pca.inverse_transform((mixed * 6.0).reshape(1, -1)) - origin).ravel()

# ------------------------------------------------------------------
# Figure: shift visualized directly in pixel space (before / after)
# ------------------------------------------------------------------
sample_idx = rng.choice(len(X_pool_s), size=6, replace=False)
fig, axes = plt.subplots(2, 6, figsize=(9, 3.2))
for col, i in enumerate(sample_idx):
    x_before_s = X_pool_s[i]
    x_after_s = x_before_s + shifted_dir
    img_before = scaler.inverse_transform(x_before_s.reshape(1, -1)).reshape(8, 8)
    img_after = scaler.inverse_transform(x_after_s.reshape(1, -1)).reshape(8, 8)

    s1_before = predictive_entropy(clf.predict_proba(x_before_s.reshape(1, -1)))[0]
    s1_after = predictive_entropy(clf.predict_proba(x_after_s.reshape(1, -1)))[0]
    s2_before = novelty.score(pca.transform(x_before_s.reshape(1, -1)))[0]
    s2_after = novelty.score(pca.transform(x_after_s.reshape(1, -1)))[0]

    axes[0, col].imshow(img_before, cmap="gray_r")
    axes[0, col].set_xticks([]); axes[0, col].set_yticks([])
    axes[0, col].set_title(f"$H$={s1_before:.2f}\n$M$={s2_before:.1f}", fontsize=7)

    axes[1, col].imshow(img_after, cmap="gray_r")
    axes[1, col].set_xticks([]); axes[1, col].set_yticks([])
    axes[1, col].set_title(f"$H$={s1_after:.2f}\n$M$={s2_after:.1f}", fontsize=7)

axes[0, 0].set_ylabel("Original", fontsize=8)
axes[1, 0].set_ylabel("Shifted", fontsize=8)
fig.suptitle("Genuine covariate shift visualized in pixel space: entropy ($H$) and Mahalanobis novelty ($M$) before/after", fontsize=8.5)
fig.tight_layout()
fig.savefig(FIGDIR + "fig_cv_shift_pixelspace.pdf", bbox_inches="tight")
plt.close(fig)
print("saved fig_cv_shift_pixelspace.pdf")

# ------------------------------------------------------------------
# Figure: 2D embedding scatter (control pool vs shifted subpopulation),
# colored by entropy, sized/marked by novelty score
# ------------------------------------------------------------------
n_show = 250
show_idx = rng.choice(len(X_pool_s), size=n_show, replace=False)
X_show = X_pool_s[show_idx]
mask_shift = rng.random(n_show) < 0.4
X_show_shifted = X_show.copy()
X_show_shifted[mask_shift] += shifted_dir[None, :]

s1_show = predictive_entropy(clf.predict_proba(X_show_shifted))
Z_show = pca.transform(X_show_shifted)
s2_show = novelty.score(Z_show)

tsne = TSNE(n_components=2, perplexity=30, random_state=0, init="pca")
emb = tsne.fit_transform(np.vstack([Z_train[:400], Z_show]))
emb_train = emb[:400]
emb_show = emb[400:]

fig, ax = plt.subplots(figsize=(5.2, 4.3))
ax.scatter(emb_train[:, 0], emb_train[:, 1], s=8, color="lightgray", label="Training manifold", zorder=1)
sc = ax.scatter(emb_show[~mask_shift, 0], emb_show[~mask_shift, 1], s=22, c=s1_show[~mask_shift],
                cmap="viridis", edgecolor="black", linewidth=0.3, label="Unshifted deployment samples", zorder=2)
ax.scatter(emb_show[mask_shift, 0], emb_show[mask_shift, 1], s=45, c=s1_show[mask_shift],
           cmap="viridis", edgecolor="red", linewidth=1.1, marker="^", label="Shifted subpopulation", zorder=3)
cbar = fig.colorbar(sc, ax=ax)
cbar.set_label("Predictive entropy $s_1$")
ax.set_xlabel("t-SNE dim. 1"); ax.set_ylabel("t-SNE dim. 2")
ax.set_title("Digit-image embedding space: shifted subpopulation\n(red triangles) vs. training manifold and normal deployment samples", fontsize=8.5)
ax.legend(fontsize=6.5, loc="upper right", framealpha=0.9)
fig.tight_layout()
fig.savefig(FIGDIR + "fig_cv_embedding_shift.pdf", bbox_inches="tight")
plt.close(fig)
print("saved fig_cv_embedding_shift.pdf")

print("done.")
