import glob
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image

FIGDIR = "/home/claude/paper/figures/"
plt.rcParams.update({"font.size": 9})
PACS_ROOT = "/home/claude/pacs_test/PACS"

# ------------------------------------------------------------------
# Figure: real PACS sample images across the four real domains
# ------------------------------------------------------------------
domains = ["photo", "art_painting", "cartoon", "sketch"]
domain_labels = ["Photo", "Art Painting", "Cartoon", "Sketch"]
classes = ["dog", "elephant", "guitar", "house"]

fig, axes = plt.subplots(len(domains), len(classes), figsize=(6.0, 6.4))
for row, (domain, dlabel) in enumerate(zip(domains, domain_labels)):
    for col, cls in enumerate(classes):
        files = sorted(glob.glob(f"{PACS_ROOT}/{domain}/{cls}/*"))
        img = Image.open(files[0]).convert("RGB")
        axes[row, col].imshow(img)
        axes[row, col].set_xticks([])
        axes[row, col].set_yticks([])
        if row == 0:
            axes[row, col].set_title(cls, fontsize=8)
    axes[row, 0].set_ylabel(dlabel, fontsize=8, rotation=90, ha="center", va="center")
fig.suptitle("Real PACS images: four genuine domains, same object categories", fontsize=9)
fig.tight_layout()
fig.savefig(FIGDIR + "fig_pacs_samples.pdf", bbox_inches="tight")
plt.close(fig)
print("saved fig_pacs_samples.pdf")

# ------------------------------------------------------------------
# Figure: CLIP+PACS results summary
# ------------------------------------------------------------------
d = json.load(open("/home/claude/paper/results/clip_pacs_results.json"))
methods = ["tau_guard", "ks", "psi", "mmd"]
labels_m = {"tau_guard": r"$\tau$-Guard", "ks": "Conf-KS", "psi": "PSI", "mmd": "MMD"}
colors = {"tau_guard": "#1b6ca8", "ks": "#d9534f", "psi": "#f0ad4e", "mmd": "#5cb85c"}

fig, axes = plt.subplots(1, 2, figsize=(8.0, 2.8))
x = np.arange(len(methods))
width = 0.35

ax = axes[0]
ctrl = [d["fpr"]["control"][m] for m in methods]
recal = [np.mean(d["fpr"]["recalibration"][m]) if isinstance(d["fpr"]["recalibration"][m], list) else d["fpr"]["recalibration"][m] for m in methods]
ctrl = [np.mean(d["fpr"]["control"][m]) for m in methods]
recal = [np.mean(d["fpr"]["recalibration"][m]) for m in methods]
ax.bar(x - width/2, ctrl, width, label="Control", color="#9ecae1", edgecolor="black", linewidth=0.4)
ax.bar(x + width/2, recal, width, label="Recalibrated", color="#08306b", edgecolor="black", linewidth=0.4)
ax.axhline(0.05, color="gray", linestyle="--", linewidth=0.8)
ax.set_xticks(x); ax.set_xticklabels([labels_m[m] for m in methods], rotation=30, ha="right", fontsize=8)
ax.set_ylabel("False-positive rate")
ax.set_title("(a) Real CLIP ViT-B/32:\ncontrol vs.\ recalibration FPR", fontsize=8.5)
ax.legend(fontsize=7, frameon=False)

ax = axes[1]
domains_short = ["art_painting", "cartoon", "sketch"]
domain_labels = ["Art", "Cartoon", "Sketch"]
xw = np.arange(len(domains_short))
w2 = 0.2
for i, m in enumerate(methods):
    gaps = [d["cross_domain_shift"][dm]["gap"][m] for dm in domains_short]
    ax.bar(xw + (i - 1.5) * w2, gaps, w2, label=labels_m[m], color=colors[m], edgecolor="black", linewidth=0.3)
ax.axhline(0, color="gray", linewidth=0.8)
ax.set_xticks(xw); ax.set_xticklabels(domain_labels, fontsize=8)
ax.set_ylabel("Flag-rate gap\n(cross-domain vs.\ within-domain)")
ax.set_title("(b) Real cross-domain shift\n(Photo $\\to$ Art/Cartoon/Sketch)", fontsize=8.5)
ax.legend(fontsize=6.5, frameon=False, ncol=2)

fig.tight_layout()
fig.savefig(FIGDIR + "fig_clip_pacs_results.pdf", bbox_inches="tight")
plt.close(fig)
print("saved fig_clip_pacs_results.pdf")
