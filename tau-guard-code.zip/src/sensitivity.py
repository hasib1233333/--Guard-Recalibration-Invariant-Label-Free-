import json
import numpy as np
from ablation import prepare_base
from method import predictive_entropy, MahalanobisNoveltyScorer, calibrate_tau_guard, tau_guard_test
from experiment_core import temp_scaled_entropy
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from data_loaders import load_dataset


def run_alpha_sensitivity(base, alphas=(0.01, 0.05, 0.10), n_trials=200, W=20, rng=None):
    if rng is None:
        rng = np.random.default_rng(50)
    Z_train = base["pca"].transform(base["X_train_s"])
    maha = MahalanobisNoveltyScorer(shrinkage=1e-2).fit(Z_train, base["y_train"])
    s1_calib = predictive_entropy(base["clf"].predict_proba(base["X_calib_s"]))
    s2_calib = maha.score(base["Z_calib"])
    results = {}
    for a in alphas:
        calib = calibrate_tau_guard(s1_calib, s2_calib, W, 1500, a, rng=np.random.default_rng(1))
        flags = []
        for _ in range(n_trials):
            idx = rng.integers(0, base["X_pool_s"].shape[0], size=W)
            Xw, Zw = base["X_pool_s"][idx], base["Z_pool"][idx]
            s1 = predictive_entropy(base["clf"].predict_proba(Xw))
            s2 = maha.score(Zw)
            flags.append(tau_guard_test(s1, s2, calib)["flag"])
        results[a] = {"empirical_fpr": float(np.mean(flags)), "nominal_alpha": a}
        print(f"alpha={a}: empirical_fpr={np.mean(flags):.3f}")
    return results


def run_temperature_sensitivity(base, temps=(1.2, 1.5, 2.5, 4.0, 6.0, 10.0), n_trials=200, W=20, rng=None):
    if rng is None:
        rng = np.random.default_rng(51)
    Z_train = base["pca"].transform(base["X_train_s"])
    maha = MahalanobisNoveltyScorer(shrinkage=1e-2).fit(Z_train, base["y_train"])
    s1_calib = predictive_entropy(base["clf"].predict_proba(base["X_calib_s"]))
    s2_calib = maha.score(base["Z_calib"])
    calib = calibrate_tau_guard(s1_calib, s2_calib, W, 1500, 0.05, rng=np.random.default_rng(1))
    results = {}
    for T in temps:
        flags = []
        for _ in range(n_trials):
            idx = rng.integers(0, base["X_pool_s"].shape[0], size=W)
            Xw, Zw = base["X_pool_s"][idx], base["Z_pool"][idx]
            s1 = temp_scaled_entropy(base["clf"], Xw, T=T)
            s2 = maha.score(Zw)
            flags.append(tau_guard_test(s1, s2, calib)["flag"])
        results[T] = {"fpr": float(np.mean(flags))}
        print(f"temperature={T}: fpr={np.mean(flags):.3f}")
    return results


def run_calib_ratio_sensitivity(dsname="digits", ratios=(2, 3, 5, 8, 15, 25), W=20, n_trials=300, seed=1):
    """Directly tests the calibration-set-size guideline: fix the
    train/pool split and window size, then vary ONLY the calibration
    subsample size (drawn from one fixed large calibration pool) as a
    multiple of W, isolating the ratio's effect from split-to-split
    sampling noise."""
    X, y = load_dataset(dsname)
    rng = np.random.default_rng(seed)
    idx_all = rng.permutation(len(X))
    n_train = 300
    n_calib_pool = min(600, len(X) - n_train - 300)
    n_pool = 300
    train_idx = idx_all[:n_train]
    calib_pool_idx = idx_all[n_train:n_train + n_calib_pool]
    pool_idx = idx_all[n_train + n_calib_pool:n_train + n_calib_pool + n_pool]

    X_train, y_train = X[train_idx], y[train_idx]
    X_calib_pool_raw, y_calib_pool = X[calib_pool_idx], y[calib_pool_idx]
    X_pool_raw = X[pool_idx]

    scaler = StandardScaler().fit(X_train)
    X_train_s = scaler.transform(X_train)
    X_calib_pool_s = scaler.transform(X_calib_pool_raw)
    X_pool_s = scaler.transform(X_pool_raw)
    n_comp = min(10, X_train_s.shape[1])
    pca = PCA(n_components=n_comp, random_state=0).fit(X_train_s)
    Z_train = pca.transform(X_train_s)
    Z_calib_pool = pca.transform(X_calib_pool_s)
    Z_pool = pca.transform(X_pool_s)
    clf = LogisticRegression(max_iter=2000).fit(X_train_s, y_train)
    maha = MahalanobisNoveltyScorer(shrinkage=1e-2).fit(Z_train, y_train)

    s1_calib_pool = predictive_entropy(clf.predict_proba(X_calib_pool_s))
    s2_calib_pool = maha.score(Z_calib_pool)

    results = {}
    for ratio in ratios:
        needed = int(ratio * W)
        if needed > n_calib_pool:
            print(f"ratio={ratio}: skipped (needs {needed} > available pool {n_calib_pool})")
            continue
        sub_idx = rng.choice(n_calib_pool, size=needed, replace=False)
        s1_calib = s1_calib_pool[sub_idx]
        s2_calib = s2_calib_pool[sub_idx]
        calib = calibrate_tau_guard(s1_calib, s2_calib, W, 1500, 0.05, rng=np.random.default_rng(2))
        flags = []
        for _ in range(n_trials):
            idx = rng.integers(0, X_pool_s.shape[0], size=W)
            Xw, Zw = X_pool_s[idx], Z_pool[idx]
            s1 = predictive_entropy(clf.predict_proba(Xw))
            s2 = maha.score(Zw)
            flags.append(tau_guard_test(s1, s2, calib)["flag"])
        results[ratio] = {"calib_size": needed, "empirical_fpr": float(np.mean(flags))}
        print(f"calib/window ratio={ratio}x (n_calib={needed}): empirical_fpr={np.mean(flags):.3f}")
    return results


def main():
    base = prepare_base("synthetic", seed=1)
    print("=== Alpha sensitivity ===")
    r1 = run_alpha_sensitivity(base)
    print("=== Temperature sensitivity ===")
    r2 = run_temperature_sensitivity(base)
    print("=== Calibration-set-size ratio sensitivity (digits, larger pool available) ===")
    r3 = run_calib_ratio_sensitivity("digits", ratios=(2, 3, 5, 8, 15, 25))
    json.dump({"alpha": r1, "temperature": r2, "calib_ratio": r3},
               open("/home/claude/paper/results/sensitivity_results.json", "w"), indent=2)
    print("saved.")


if __name__ == "__main__":
    main()
