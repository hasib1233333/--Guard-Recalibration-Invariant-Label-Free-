import numpy as np
from experiment_core import (
    prepare_dataset, calibrate_all_methods, sample_window, eval_window, temp_scaled_entropy,
)
from method import predictive_entropy


def sample_pca_aligned_direction(ds, rng, magnitude=6.0, sensitivity_mix=0.7):
    n_comp = ds["pca"].n_components_
    eigval, eigvec = np.linalg.eigh(ds["novelty"].precision_)
    max_sens_dir = eigvec[:, np.argmax(eigval)]
    if rng.random() < 0.5:
        max_sens_dir = -max_sens_dir
    rand_dir = rng.normal(size=n_comp)
    rand_dir /= np.linalg.norm(rand_dir)
    mixed = sensitivity_mix * max_sens_dir + (1 - sensitivity_mix) * rand_dir
    mixed /= np.linalg.norm(mixed)
    origin = ds["pca"].inverse_transform(np.zeros((1, n_comp)))
    shifted = ds["pca"].inverse_transform((mixed * magnitude).reshape(1, -1))
    return (shifted - origin).ravel()


def run_fpr_scenarios(ds, calib, rng, n_trials=250, temperature=2.5):
    methods = list(calib.keys())
    results = {"control": {m: [] for m in methods}, "recalibration": {m: [] for m in methods}}
    for t in range(n_trials):
        X_win, Z_win, idx = sample_window(ds, rng)
        out = eval_window(ds, calib, X_win, Z_win, rng=rng)
        for m in methods:
            results["control"][m].append(out[m]["flag"])
        s1_T = temp_scaled_entropy(ds["clf"], X_win, T=temperature)
        out_T = eval_window(ds, calib, X_win, Z_win, s1_override=s1_T, rng=rng)
        for m in methods:
            results["recalibration"][m].append(out_T[m]["flag"])
    return results


def run_shift_scenarios(ds, calib, rng, n_trials=100, n_windows=15, onset=5,
                         shift_sigma=6.0, contamination_frac=0.45, temperature=2.5):
    methods = list(calib.keys())
    results = {"shift_only": {m: {"pre_rate": [], "post_rate": []} for m in methods},
                "shift_plus_recal": {m: {"pre_rate": [], "post_rate": []} for m in methods}}
    for scenario, apply_recal in [("shift_only", False), ("shift_plus_recal", True)]:
        for t in range(n_trials):
            direction = sample_pca_aligned_direction(ds, rng, magnitude=shift_sigma)
            flags = {m: np.zeros(n_windows, dtype=int) for m in methods}
            for w in range(n_windows):
                X_win, Z_win, idx = sample_window(ds, rng)
                if w >= onset:
                    mask = rng.random(X_win.shape[0]) < contamination_frac
                    X_win = X_win.copy()
                    X_win[mask] += direction[None, :]
                    Z_win = ds["pca"].transform(X_win)
                s1 = temp_scaled_entropy(ds["clf"], X_win, T=temperature) if apply_recal else None
                out = eval_window(ds, calib, X_win, Z_win, s1_override=s1, rng=rng)
                for m in methods:
                    flags[m][w] = out[m]["flag"]
            for m in methods:
                results[scenario][m]["pre_rate"].append(float(flags[m][:onset].mean()))
                results[scenario][m]["post_rate"].append(float(flags[m][onset:].mean()))
    return results
