import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.lines import Line2D

FIGDIR = "/home/claude/paper/figures/"
plt.rcParams.update({"font.size": 9})


def box(ax, xy, w, h, text, fc="#e8f1fa", ec="#1b6ca8", fontsize=7.5):
    b = FancyBboxPatch((xy[0], xy[1]), w, h, boxstyle="round,pad=0.02,rounding_size=0.04",
                        linewidth=1.1, edgecolor=ec, facecolor=fc)
    ax.add_patch(b)
    ax.text(xy[0] + w / 2, xy[1] + h / 2, text, ha="center", va="center", fontsize=fontsize, wrap=True)
    return (xy[0] + w / 2, xy[1] + h / 2)


def arrow(ax, p1, p2, text=None, color="black"):
    a = FancyArrowPatch(p1, p2, arrowstyle="-|>", mutation_scale=10, linewidth=1.0, color=color)
    ax.add_patch(a)
    if text:
        mx, my = (p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2
        ax.text(mx, my + 0.02, text, ha="center", va="bottom", fontsize=6.5, color=color)


# ------------------------------------------------------------------
# Figure: overall tau-Guard pipeline (training / calibration / deployment)
# ------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(7.2, 3.4))
ax.set_xlim(0, 10); ax.set_ylim(0, 5); ax.axis("off")

# Phase labels
ax.text(1.5, 4.75, "Training phase", fontsize=8, fontweight="bold", color="#08306b", ha="center")
ax.text(5.0, 4.75, "Calibration phase", fontsize=8, fontweight="bold", color="#08306b", ha="center")
ax.text(8.3, 4.75, "Deployment (online monitoring)", fontsize=8, fontweight="bold", color="#08306b", ha="center")
ax.axvline(3.2, color="lightgray", linewidth=1, ymin=0.05, ymax=0.92)
ax.axvline(6.7, color="lightgray", linewidth=1, ymin=0.05, ymax=0.92)

# Training phase
p_train = box(ax, (0.3, 3.6), 2.4, 0.7, "Training data\n(X_train, y_train)")
p_clf = box(ax, (0.3, 2.5), 2.4, 0.7, "Fit classifier $f$")
p_nov = box(ax, (0.3, 1.4), 2.4, 0.7, "Fit novelty scorer\n(class centroids, $\\Sigma^{-1}$)")
arrow(ax, (p_train[0], p_train[1]-0.35), (p_clf[0], p_clf[1]+0.35))
arrow(ax, (p_clf[0], p_clf[1]-0.35), (p_nov[0], p_nov[1]+0.35))

# Calibration phase
p_calibdata = box(ax, (3.5, 3.6), 2.4, 0.7, "Held-out calibration\nset $X_{calib}$")
p_signals = box(ax, (3.5, 2.5), 2.4, 0.7, "Compute $s_1$ (entropy),\n$s_2$ (Mahalanobis)")
p_boot = box(ax, (3.5, 1.4), 2.4, 0.9, "Bootstrap windows,\ncompute $\\hat\\tau^{(b)}$,\nset threshold $[\\ell, u]$")
arrow(ax, (p_calibdata[0], p_calibdata[1]-0.35), (p_signals[0], p_signals[1]+0.35))
arrow(ax, (p_signals[0], p_signals[1]-0.35), (p_boot[0], p_boot[1]+0.45))
arrow(ax, (p_clf[0]+1.2, p_clf[1]), (p_signals[0]-1.2, p_signals[1]), color="gray")
arrow(ax, (p_nov[0]+1.2, p_nov[1]), (p_signals[0]-1.2, p_signals[1]-0.3), color="gray")

# Deployment phase
p_stream = box(ax, (7.0, 3.7), 2.7, 0.6, "Unlabeled stream window $W_t$")
p_s1s2 = box(ax, (7.0, 2.75), 2.7, 0.6, "$s_1(W_t)$, $s_2(W_t)$")
p_tau = box(ax, (7.0, 1.8), 2.7, 0.6, "$\\hat\\tau_t$ = Kendall($s_1, s_2$)")
p_alarm = box(ax, (7.0, 0.7), 2.7, 0.7, "Flag drift if\n$\\hat\\tau_t \\notin [\\ell, u]$", fc="#fde9e7", ec="#d9534f")
arrow(ax, (p_stream[0], p_stream[1]-0.3), (p_s1s2[0], p_s1s2[1]+0.3))
arrow(ax, (p_s1s2[0], p_s1s2[1]-0.3), (p_tau[0], p_tau[1]+0.3))
arrow(ax, (p_tau[0], p_tau[1]-0.3), (p_alarm[0], p_alarm[1]+0.35))
arrow(ax, (p_boot[0]+1.2, p_boot[1]), (p_alarm[0]-1.35, p_alarm[1]+0.1), color="gray")

fig.savefig(FIGDIR + "fig_schematic_pipeline.pdf", bbox_inches="tight")
plt.close(fig)
print("saved fig_schematic_pipeline.pdf")

# ------------------------------------------------------------------
# Figure: recalibration illustration (rank preserved under monotone remap)
# ------------------------------------------------------------------
rng = np.random.default_rng(3)
n = 12
s1 = rng.uniform(0.05, 0.9, size=n)
s2 = 0.5 * s1 + rng.normal(0, 0.12, size=n)
order = np.argsort(s1)
s1_sorted = s1[order]
# monotone recalibration: sigmoid remap
s1_recal = 1 / (1 + np.exp(-6 * (s1_sorted - 0.45)))

fig, axes = plt.subplots(1, 3, figsize=(7.4, 2.4))

ax = axes[0]
ax.scatter(s1_sorted, s2[order], color="#1b6ca8", edgecolor="black", linewidth=0.4, s=35)
ax.set_title("Before recalibration", fontsize=8.5)
ax.set_xlabel("Confidence signal $s_1$"); ax.set_ylabel("Novelty signal $s_2$")
tau0 = np.corrcoef(np.argsort(np.argsort(s1_sorted)), np.argsort(np.argsort(s2[order])))[0, 1]

ax = axes[1]
xs = np.linspace(0, 1, 100)
ys = 1 / (1 + np.exp(-6 * (xs - 0.45)))
ax.plot(xs, ys, color="#d9534f", linewidth=1.3)
ax.scatter(s1_sorted, s1_recal, color="#d9534f", s=18, zorder=3)
ax.set_title("Monotone recalibration\n(e.g. Platt scaling)", fontsize=8.5)
ax.set_xlabel("Original $s_1$"); ax.set_ylabel("Recalibrated $s_1$")

ax = axes[2]
ax.scatter(s1_recal, s2[order], color="#1b6ca8", edgecolor="black", linewidth=0.4, s=35)
ax.set_title("After recalibration", fontsize=8.5)
ax.set_xlabel("Recalibrated $s_1$"); ax.set_ylabel("Novelty signal $s_2$")

fig.text(0.5, -0.05, r"Same rank order in both scatter plots $\Rightarrow$ identical $\hat\tau$ (Lemma 1): "
                       r"$\hat\tau_{\mathrm{before}} = \hat\tau_{\mathrm{after}}$ exactly.",
          ha="center", fontsize=8)
fig.tight_layout()
fig.savefig(FIGDIR + "fig_recalibration_illustration.pdf", bbox_inches="tight")
plt.close(fig)
print("saved fig_recalibration_illustration.pdf")
