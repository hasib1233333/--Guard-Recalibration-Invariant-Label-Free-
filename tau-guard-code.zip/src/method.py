"""
tau-Guard: recalibration-invariant, label-free drift detection via
cross-signal rank-agreement decay.

This module implements:
  - the two per-sample uncertainty signals (predictive entropy, feature-space
    Mahalanobis novelty score)
  - the tau-Guard test statistic and bootstrap calibration procedure
  - three label-free baselines: Confidence-KS, PSI, and a feature-space
    MMD-style embedding-shift test (proxy for embedding-distributional
    monitors such as DriftLens)
"""
import numpy as np
from scipy import stats


# ----------------------------------------------------------------------
# Signals
# ----------------------------------------------------------------------

def predictive_entropy(proba, eps=1e-12):
    """Shannon entropy of the predicted class distribution, per sample."""
    p = np.clip(proba, eps, 1.0)
    return -np.sum(p * np.log(p), axis=1)


class MahalanobisNoveltyScorer:
    """Feature-space novelty score: min over classes of the Mahalanobis
    distance from x to the class centroid, using a shrinkage-regularized
    pooled covariance estimated on the reference (training) data.

    This score depends only on the input features X, not on the
    classifier's output layer, so it is a signal of a conceptually
    different nature than predictive-probability-based uncertainty.
    """

    def __init__(self, shrinkage=1e-3):
        self.shrinkage = shrinkage
        self.centroids_ = None
        self.precision_ = None

    def fit(self, X, y):
        classes = np.unique(y)
        d = X.shape[1]
        self.classes_ = classes
        self.centroids_ = np.stack([X[y == c].mean(axis=0) for c in classes])
        # pooled (within-class) covariance with shrinkage for numerical stability
        cov = np.zeros((d, d))
        n_total = 0
        for c in classes:
            Xc = X[y == c]
            nc = Xc.shape[0]
            if nc > 1:
                cov += (nc - 1) * np.cov(Xc, rowvar=False)
            n_total += nc
        cov /= max(n_total - len(classes), 1)
        cov = (1 - self.shrinkage) * cov + self.shrinkage * np.eye(d) * np.trace(cov) / d
        self.precision_ = np.linalg.inv(cov)
        return self

    def score(self, X):
        dists = np.zeros((X.shape[0], len(self.classes_)))
        for i, c in enumerate(self.classes_):
            diff = X - self.centroids_[i]
            dists[:, i] = np.einsum('ij,jk,ik->i', diff, self.precision_, diff)
        return dists.min(axis=1)


# ----------------------------------------------------------------------
# tau-Guard
# ----------------------------------------------------------------------

def kendall_tau(s1, s2):
    tau, _ = stats.kendalltau(s1, s2)
    if np.isnan(tau):
        tau = 0.0
    return tau


def spearman_rho(s1, s2):
    rho, _ = stats.spearmanr(s1, s2)
    if np.isnan(rho):
        rho = 0.0
    return rho


RANK_STATISTICS = {"kendall": kendall_tau, "spearman": spearman_rho}


class EuclideanNoveltyScorer:
    """Ablation variant: unweighted Euclidean distance to the nearest
    class centroid (ignores covariance structure), to isolate how much
    of tau-Guard's behavior depends specifically on the Mahalanobis
    (covariance-aware) formulation."""

    def fit(self, X, y):
        classes = np.unique(y)
        self.classes_ = classes
        self.centroids_ = np.stack([X[y == c].mean(axis=0) for c in classes])
        return self

    def score(self, X):
        dists = np.zeros((X.shape[0], len(self.classes_)))
        for i in range(len(self.classes_)):
            dists[:, i] = np.sum((X - self.centroids_[i]) ** 2, axis=1)
        return dists.min(axis=1)


class KNNNoveltyScorer:
    """Ablation variant: mean distance to the k nearest training points
    (a nonparametric novelty score with no Gaussian-class assumption)."""

    def __init__(self, k=10):
        self.k = k

    def fit(self, X, y):
        self.X_train_ = X
        return self

    def score(self, X):
        d2 = np.sum((X[:, None, :] - self.X_train_[None, :, :]) ** 2, axis=-1)
        d2.sort(axis=1)
        k = min(self.k, d2.shape[1])
        return d2[:, :k].mean(axis=1)


def calibrate_tau_guard(s1_calib, s2_calib, window_size, n_bootstrap=2000,
                         alpha=0.05, rng=None, rank_stat=kendall_tau):
    """Bootstrap the null distribution of the windowed Kendall's tau
    statistic under H0 (i.i.d. draws from the reference distribution).

    Returns tau0 (center), and a two-sided rejection region
    [lo, hi] calibrated so that, under H0, P(tau_hat outside [lo,hi]) ~ alpha.
    """
    if rng is None:
        rng = np.random.default_rng(0)
    n = len(s1_calib)
    taus = np.empty(n_bootstrap)
    for b in range(n_bootstrap):
        idx = rng.integers(0, n, size=window_size)
        taus[b] = rank_stat(s1_calib[idx], s2_calib[idx])
    tau0 = float(np.mean(taus))
    lo = float(np.quantile(taus, alpha / 2))
    hi = float(np.quantile(taus, 1 - alpha / 2))
    sigma0 = float(np.std(taus))
    return {"tau0": tau0, "lo": lo, "hi": hi, "sigma0": sigma0, "boot_taus": taus, "rank_stat": rank_stat}


def tau_guard_test(s1_window, s2_window, calib):
    rank_stat = calib.get("rank_stat", kendall_tau)
    tau_hat = rank_stat(s1_window, s2_window)
    flag = int(tau_hat < calib["lo"] or tau_hat > calib["hi"])
    z = (tau_hat - calib["tau0"]) / (calib["sigma0"] + 1e-12)
    return {"stat": tau_hat, "flag": flag, "z": z}


# ----------------------------------------------------------------------
# Baselines
# ----------------------------------------------------------------------

def calibrate_ks_baseline(s1_calib, window_size, n_bootstrap=2000, alpha=0.05, rng=None):
    """Confidence-KS: two-sample KS test between a reference sample of s1
    and the current window's s1. Threshold on the KS statistic is
    bootstrap-calibrated (rather than using the asymptotic KS p-value
    directly) so that every method in the comparison is calibrated by
    the identical resampling protocol.
    """
    if rng is None:
        rng = np.random.default_rng(1)
    n = len(s1_calib)
    stats_null = np.empty(n_bootstrap)
    for b in range(n_bootstrap):
        ref_idx = rng.integers(0, n, size=n)
        win_idx = rng.integers(0, n, size=window_size)
        d, _ = stats.ks_2samp(s1_calib[ref_idx], s1_calib[win_idx])
        stats_null[b] = d
    thresh = float(np.quantile(stats_null, 1 - alpha))
    return {"reference": s1_calib.copy(), "thresh": thresh}


def ks_baseline_test(s1_window, calib):
    d, _ = stats.ks_2samp(calib["reference"], s1_window)
    return {"stat": d, "flag": int(d > calib["thresh"])}


def _psi(reference, window, n_bins=10):
    edges = np.quantile(reference, np.linspace(0, 1, n_bins + 1))
    edges[0], edges[-1] = -np.inf, np.inf
    edges = np.unique(edges)
    ref_hist, _ = np.histogram(reference, bins=edges)
    win_hist, _ = np.histogram(window, bins=edges)
    ref_p = ref_hist / max(ref_hist.sum(), 1) + 1e-6
    win_p = win_hist / max(win_hist.sum(), 1) + 1e-6
    return float(np.sum((win_p - ref_p) * np.log(win_p / ref_p)))


def calibrate_psi_baseline(s1_calib, window_size, n_bootstrap=2000, alpha=0.05, rng=None):
    if rng is None:
        rng = np.random.default_rng(2)
    n = len(s1_calib)
    stats_null = np.empty(n_bootstrap)
    for b in range(n_bootstrap):
        ref_idx = rng.integers(0, n, size=n)
        win_idx = rng.integers(0, n, size=window_size)
        stats_null[b] = _psi(s1_calib[ref_idx], s1_calib[win_idx])
    thresh = float(np.quantile(stats_null, 1 - alpha))
    return {"reference": s1_calib.copy(), "thresh": thresh}


def psi_baseline_test(s1_window, calib):
    val = _psi(calib["reference"], s1_window)
    return {"stat": val, "flag": int(val > calib["thresh"])}


def _linear_mmd2(X, Y):
    """Unbiased linear-time estimator of MMD^2 with an RBF kernel using the
    median heuristic bandwidth, computed on paired consecutive samples
    (Gretton et al. 2012, linear-time statistic) for O(n) cost.
    """
    n = min(len(X), len(Y))
    n = n - (n % 2)
    if n < 4:
        return 0.0
    X, Y = X[:n], Y[:n]
    Z = np.vstack([X, Y])
    d2 = np.sum((Z[:, None, :] - Z[None, :, :]) ** 2, axis=-1)
    sigma2 = np.median(d2[d2 > 0]) + 1e-8

    def k(a, b):
        return np.exp(-np.sum((a - b) ** 2, axis=-1) / (2 * sigma2))

    h = k(X[0::2], X[1::2]) + k(Y[0::2], Y[1::2]) - k(X[0::2], Y[1::2]) - k(X[1::2], Y[0::2])
    return float(np.mean(h))


def calibrate_mmd_baseline(Z_calib, window_size, n_bootstrap=2000, alpha=0.05, rng=None):
    """Feature-space (embedding) shift baseline: linear-time MMD between a
    reference sample and the current window, computed on the same
    (PCA) embedding used for the Mahalanobis novelty score. Serves as a
    proxy for embedding-distributional drift monitors."""
    if rng is None:
        rng = np.random.default_rng(3)
    n = len(Z_calib)
    stats_null = np.empty(n_bootstrap)
    for b in range(n_bootstrap):
        ref_idx = rng.integers(0, n, size=n)
        win_idx = rng.integers(0, n, size=window_size)
        stats_null[b] = _linear_mmd2(Z_calib[ref_idx], Z_calib[win_idx])
    thresh = float(np.quantile(stats_null, 1 - alpha))
    return {"reference": Z_calib.copy(), "thresh": thresh}


def mmd_baseline_test(Z_window, calib):
    val = _linear_mmd2(calib["reference"], Z_window)
    return {"stat": val, "flag": int(val > calib["thresh"])}


# ----------------------------------------------------------------------
# Additional baseline: Page-Hinkley test (Page 1954), applied to the
# windowed mean of the entropy signal -- a classical sequential-analysis
# drift detector used widely in the concept-drift literature (e.g. STUDD).
# ----------------------------------------------------------------------

class PageHinkley:
    """Two-sided Page-Hinkley test for a change in the mean of a signal
    (Page 1954). The reference mean is fixed at the value estimated on
    the calibration split. Following the standard formulation:
      m_T = sum_{t<=T} (x_t - ref_mean - delta)   [cumulative deviation]
      PH_up   = m_T - min_{t<=T} m_t   (large  => sustained increase)
      PH_down = max_{t<=T} m_t - m_T   (large  => sustained decrease)
    Both directions are tracked since either a benign recalibration or a
    genuine shift may move the mean signal up or down.
    """

    def __init__(self, delta=0.005):
        self.delta = delta

    def statistics_over_window(self, window_signal, ref_mean):
        m_T = 0.0
        min_m = 0.0
        max_m = 0.0
        for x in window_signal:
            m_T = m_T + (x - ref_mean - self.delta)
            min_m = min(min_m, m_T)
            max_m = max(max_m, m_T)
        PH_up = m_T - min_m
        PH_down = max_m - m_T
        return PH_up, PH_down


def calibrate_ph_baseline(s1_calib, window_size, n_bootstrap=2000, alpha=0.05, rng=None, delta=None):
    if rng is None:
        rng = np.random.default_rng(4)
    n = len(s1_calib)
    ref_mean = float(np.mean(s1_calib))
    if delta is None:
        delta = 0.5 * float(np.std(s1_calib)) / np.sqrt(window_size)
    ph = PageHinkley(delta=delta)
    up_null = np.empty(n_bootstrap)
    down_null = np.empty(n_bootstrap)
    for b in range(n_bootstrap):
        idx = rng.integers(0, n, size=window_size)
        up, down = ph.statistics_over_window(s1_calib[idx], ref_mean)
        up_null[b], down_null[b] = up, down
    thresh_up = float(np.quantile(up_null, 1 - alpha / 2))
    thresh_down = float(np.quantile(down_null, 1 - alpha / 2))
    return {"ref_mean": ref_mean, "thresh_up": thresh_up, "thresh_down": thresh_down, "delta": delta}


def ph_baseline_test(s1_window, calib):
    ph = PageHinkley(delta=calib["delta"])
    up, down = ph.statistics_over_window(s1_window, calib["ref_mean"])
    flag = int(up > calib["thresh_up"] or down > calib["thresh_down"])
    return {"stat": max(up, down), "flag": flag}


# ----------------------------------------------------------------------
# Ablation variants: alternative rank statistic (Spearman's rho) and
# alternative novelty score (Euclidean distance to nearest centroid,
# i.e. dropping the inverse-covariance / Mahalanobis weighting).
# ----------------------------------------------------------------------

def spearman_rho(s1, s2):
    rho, _ = stats.spearmanr(s1, s2)
    if np.isnan(rho):
        rho = 0.0
    return rho


def calibrate_rank_stat(s1_calib, s2_calib, window_size, n_bootstrap, alpha, rng, stat_fn):
    if rng is None:
        rng = np.random.default_rng(0)
    n = len(s1_calib)
    vals = np.empty(n_bootstrap)
    for b in range(n_bootstrap):
        idx = rng.integers(0, n, size=window_size)
        vals[b] = stat_fn(s1_calib[idx], s2_calib[idx])
    lo, hi = float(np.quantile(vals, alpha / 2)), float(np.quantile(vals, 1 - alpha / 2))
    return {"lo": lo, "hi": hi, "center": float(np.mean(vals))}


def rank_stat_test(s1_window, s2_window, calib, stat_fn):
    val = stat_fn(s1_window, s2_window)
    flag = int(val < calib["lo"] or val > calib["hi"])
    return {"stat": val, "flag": flag}


class EuclideanNoveltyScorer:
    """Ablation variant of MahalanobisNoveltyScorer: plain squared Euclidean
    distance to the nearest class centroid, i.e. no inverse-covariance
    reweighting. Used to isolate the contribution of the Mahalanobis
    metric in the ablation study."""

    def fit(self, X, y):
        classes = np.unique(y)
        self.classes_ = classes
        self.centroids_ = np.stack([X[y == c].mean(axis=0) for c in classes])
        return self

    def score(self, X):
        dists = np.zeros((X.shape[0], len(self.classes_)))
        for i in range(len(self.classes_)):
            diff = X - self.centroids_[i]
            dists[:, i] = np.sum(diff ** 2, axis=1)
        return dists.min(axis=1)


# ----------------------------------------------------------------------
# STUDD (student-teacher) baseline -- Cerqueira et al. 2021
# ----------------------------------------------------------------------

def fit_studd_student(X_train, teacher_clf, student_ctor):
    """Fit an auxiliary 'student' model to mimic the teacher's predicted
    labels (not the true labels) on the training inputs, following the
    student-teacher paradigm of STUDD."""
    y_teacher = teacher_clf.predict(X_train)
    student = student_ctor()
    student.fit(X_train, y_teacher)
    return student


def studd_mimicking_error(X, teacher_clf, student_clf):
    """Per-sample binary disagreement between teacher and student
    predictions (the raw signal STUDD feeds to a change detector)."""
    y_teacher = teacher_clf.predict(X)
    y_student = student_clf.predict(X)
    return (y_teacher != y_student).astype(float)


def calibrate_studd_baseline(X_calib, teacher_clf, student_clf, window_size,
                              n_bootstrap=2000, alpha=0.05, rng=None):
    err_calib = studd_mimicking_error(X_calib, teacher_clf, student_clf)
    if rng is None:
        rng = np.random.default_rng(4)
    n = len(err_calib)
    stats_null = np.empty(n_bootstrap)
    for b in range(n_bootstrap):
        idx = rng.integers(0, n, size=window_size)
        stats_null[b] = err_calib[idx].mean()
    thresh = float(np.quantile(stats_null, 1 - alpha))
    return {"err_calib_mean": float(err_calib.mean()), "thresh": thresh}


def studd_baseline_test(X_window, teacher_clf, student_clf, calib):
    err = studd_mimicking_error(X_window, teacher_clf, student_clf).mean()
    return {"stat": float(err), "flag": int(err > calib["thresh"])}


# ----------------------------------------------------------------------
# D3 (Discriminative Drift Detector) baseline -- Goezuecik et al. 2019
# ----------------------------------------------------------------------

def calibrate_d3_baseline(X_calib, window_size, n_bootstrap=2000, alpha=0.05,
                           rng=None, discriminator_ctor=None):
    """D3 trains a binary discriminator to distinguish an older reference
    slice from a newer slice of the SAME calibration stream; under H0
    (no drift) its held-out AUC should be ~0.5. We bootstrap the null
    distribution of this AUC statistic directly, exactly analogous to
    our other baselines, for a fair apples-to-apples comparison."""
    from sklearn.linear_model import LogisticRegression
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import roc_auc_score
    if discriminator_ctor is None:
        discriminator_ctor = lambda: LogisticRegression(max_iter=200)
    if rng is None:
        rng = np.random.default_rng(5)
    n = len(X_calib)
    stats_null = np.empty(n_bootstrap)
    for b in range(n_bootstrap):
        ref_idx = rng.integers(0, n, size=window_size)
        win_idx = rng.integers(0, n, size=window_size)
        Xd = np.vstack([X_calib[ref_idx], X_calib[win_idx]])
        yd = np.concatenate([np.zeros(window_size), np.ones(window_size)])
        try:
            Xtr, Xte, ytr, yte = train_test_split(Xd, yd, test_size=0.5,
                                                    random_state=int(rng.integers(1e6)), stratify=yd)
            clf = discriminator_ctor()
            clf.fit(Xtr, ytr)
            auc = roc_auc_score(yte, clf.predict_proba(Xte)[:, 1])
        except Exception:
            auc = 0.5
        stats_null[b] = auc
    thresh = float(np.quantile(stats_null, 1 - alpha))
    return {"reference": X_calib.copy(), "thresh": thresh, "discriminator_ctor": discriminator_ctor}


def d3_baseline_test(X_window, calib, rng=None):
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import roc_auc_score
    if rng is None:
        rng = np.random.default_rng()
    n_ref = len(calib["reference"])
    ref_idx = rng.integers(0, n_ref, size=len(X_window))
    Xd = np.vstack([calib["reference"][ref_idx], X_window])
    yd = np.concatenate([np.zeros(len(X_window)), np.ones(len(X_window))])
    try:
        Xtr, Xte, ytr, yte = train_test_split(Xd, yd, test_size=0.5,
                                                random_state=int(rng.integers(1e6)), stratify=yd)
        clf = calib["discriminator_ctor"]()
        clf.fit(Xtr, ytr)
        auc = roc_auc_score(yte, clf.predict_proba(Xte)[:, 1])
    except Exception:
        auc = 0.5
    return {"stat": float(auc), "flag": int(auc > calib["thresh"])}
