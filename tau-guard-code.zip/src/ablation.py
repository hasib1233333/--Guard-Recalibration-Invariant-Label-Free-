import json
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

from data_loaders import load_dataset
from method import (
    predictive_entropy, MahalanobisNoveltyScorer, EuclideanNoveltyScorer, KNNNoveltyScorer, EnergyNoveltyScorer,
    kendall_tau, spearman_rho, calibrate_tau_guard, tau_guard_test,
)
from scenarios import sample_pca_aligned_direction


def prepare_base(dsname="synthetic", seed=1):
    rng = np.random.default_rng(seed)
    X, y = load_dataset(dsname)
    X_train, X_rest, y_train, y_rest = train_test_split(X, y, test_size=0.65, random_state=seed, stratify=y)
    X_calib, X_pool, y_calib, y_pool = train_test_split(X_rest, y_rest, test_size=0.46, random_state=seed, stratify=y_rest)
    scaler = StandardScaler().fit(X_train)
    X_train_s, X_calib_s, X_pool_s = scaler.transform(X_train), scaler.transform(X_calib), scaler.transform(X_pool)
    n_comp = min(10, X_train_s.shape[1])
    pca = PCA(n_components=n_comp, random_state=0).fit(X_train_s)
    Z_train, Z_calib, Z_pool = pca.transform(X_train_s), pca.transform(X_calib_s), pca.transform(X_pool_s)
    clf = LogisticRegression(max_iter=2000).fit(X_train_s, y_train)
    return dict(X_train_s=X_train_s, y_train=y_train, X_calib_s=X_calib_s, Z_calib=Z_calib,
                X_pool_s=X_pool_s, Z_pool=Z_pool, y_pool=y_pool, clf=clf, pca=pca,
                scaler=scaler, n_features=X_train_s.shape[1])


def run_ablation_window_size(base, window_sizes=(10, 20, 40, 80), n_trials=150, n_bootstrap=1500, rng=None):
    if rng is None:
        rng = np.random.default_rng(42)
    novelty = MahalanobisNoveltyScorer(shrinkage=1e-2).fit(base["pca"].transform(base["X_train_s"]), base["y_train"])
    s2_calib_full = novelty.score(base["Z_calib"])
    s1_calib_full = predictive_entropy(base["clf"].predict_proba(base["X_calib_s"]))
    results = {}
    for W in window_sizes:
        calib = calibrate_tau_guard(s1_calib_full, s2_calib_full, W, n_bootstrap, 0.05, rng=rng)
        flags = []
        for _ in range(n_trials):
            idx = rng.integers(0, base["X_pool_s"].shape[0], size=W)
            Xw, Zw = base["X_pool_s"][idx], base["Z_pool"][idx]
            s1 = predictive_entropy(base["clf"].predict_proba(Xw))
            s2 = novelty.score(Zw)
            flags.append(tau_guard_test(s1, s2, calib)["flag"])
        results[W] = {"control_fpr": float(np.mean(flags)), "calib_size": len(s1_calib_full), "ratio": len(s1_calib_full) / W}
        print(f"window={W}: control_fpr={np.mean(flags):.3f} (calib/window ratio={len(s1_calib_full)/W:.1f})")
    return results


def run_ablation_bootstrap_size(base, boot_sizes=(200, 500, 1000, 2000, 4000), n_trials=150, W=20, rng=None):
    if rng is None:
        rng = np.random.default_rng(43)
    novelty = MahalanobisNoveltyScorer(shrinkage=1e-2).fit(base["pca"].transform(base["X_train_s"]), base["y_train"])
    s2_calib_full = novelty.score(base["Z_calib"])
    s1_calib_full = predictive_entropy(base["clf"].predict_proba(base["X_calib_s"]))
    results = {}
    for B in boot_sizes:
        thresh_los, thresh_his, fprs = [], [], []
        for rep in range(5):
            calib = calibrate_tau_guard(s1_calib_full, s2_calib_full, W, B, 0.05,
                                          rng=np.random.default_rng(1000 + rep))
            thresh_los.append(calib["lo"]); thresh_his.append(calib["hi"])
            flags = []
            for _ in range(n_trials // 5):
                idx = rng.integers(0, base["X_pool_s"].shape[0], size=W)
                Xw, Zw = base["X_pool_s"][idx], base["Z_pool"][idx]
                s1 = predictive_entropy(base["clf"].predict_proba(Xw))
                s2 = novelty.score(Zw)
                flags.append(tau_guard_test(s1, s2, calib)["flag"])
            fprs.append(np.mean(flags))
        results[B] = {"thresh_lo_std": float(np.std(thresh_los)), "thresh_hi_std": float(np.std(thresh_his)),
                       "fpr_mean": float(np.mean(fprs)), "fpr_std": float(np.std(fprs))}
        print(f"n_bootstrap={B}: threshold std(lo)={np.std(thresh_los):.4f} std(hi)={np.std(thresh_his):.4f} "
              f"fpr={np.mean(fprs):.3f}+/-{np.std(fprs):.3f}")
    return results


def run_ablation_novelty_score(base, n_trials=150, W=20, rng=None):
    if rng is None:
        rng = np.random.default_rng(44)
    s1_calib_full = predictive_entropy(base["clf"].predict_proba(base["X_calib_s"]))
    Z_train = base["pca"].transform(base["X_train_s"])
    maha = MahalanobisNoveltyScorer(shrinkage=1e-2).fit(Z_train, base["y_train"])
    eucl = EuclideanNoveltyScorer().fit(Z_train, base["y_train"])
    knn = KNNNoveltyScorer(k=10).fit(Z_train, base["y_train"])
    energy = EnergyNoveltyScorer(T=1.0)

    def get_logits(clf, X):
        z = clf.decision_function(X)
        if z.ndim == 1:
            z = np.stack([-z / 2, z / 2], axis=1)
        return z

    results = {}
    for name, scorer, uses_logits in [("mahalanobis", maha, False), ("euclidean", eucl, False),
                                        ("knn", knn, False), ("energy", energy, True)]:
        if uses_logits:
            s2_calib_full = scorer.score(get_logits(base["clf"], base["X_calib_s"]))
        else:
            s2_calib_full = scorer.score(base["Z_calib"])
        calib = calibrate_tau_guard(s1_calib_full, s2_calib_full, W, 1500, 0.05, rng=np.random.default_rng(1))
        flags = []
        for _ in range(n_trials):
            idx = rng.integers(0, base["X_pool_s"].shape[0], size=W)
            Xw, Zw = base["X_pool_s"][idx], base["Z_pool"][idx]
            s1 = predictive_entropy(base["clf"].predict_proba(Xw))
            s2 = scorer.score(get_logits(base["clf"], Xw)) if uses_logits else scorer.score(Zw)
            flags.append(tau_guard_test(s1, s2, calib)["flag"])
        shift_flags = []
        direction_ds = {"pca": base["pca"], "novelty": maha}
        for _ in range(n_trials):
            direction = sample_pca_aligned_direction(direction_ds, rng, magnitude=6.0)
            idx = rng.integers(0, base["X_pool_s"].shape[0], size=W)
            Xw = base["X_pool_s"][idx].copy()
            mask = rng.random(W) < 0.45
            Xw[mask] += direction[None, :]
            Zw = base["pca"].transform(Xw)
            s1 = predictive_entropy(base["clf"].predict_proba(Xw))
            s2 = scorer.score(get_logits(base["clf"], Xw)) if uses_logits else scorer.score(Zw)
            shift_flags.append(tau_guard_test(s1, s2, calib)["flag"])
        results[name] = {"control_fpr": float(np.mean(flags)), "shift_flag_rate": float(np.mean(shift_flags))}
        print(f"novelty={name}: control_fpr={np.mean(flags):.3f} shift_flag_rate={np.mean(shift_flags):.3f}")
    return results


def run_ablation_rank_statistic(base, n_trials=150, W=20, rng=None):
    if rng is None:
        rng = np.random.default_rng(45)
    Z_train = base["pca"].transform(base["X_train_s"])
    maha = MahalanobisNoveltyScorer(shrinkage=1e-2).fit(Z_train, base["y_train"])
    s1_calib_full = predictive_entropy(base["clf"].predict_proba(base["X_calib_s"]))
    s2_calib_full = maha.score(base["Z_calib"])
    results = {}
    for name, stat_fn in [("kendall", kendall_tau), ("spearman", spearman_rho)]:
        calib = calibrate_tau_guard(s1_calib_full, s2_calib_full, W, 1500, 0.05,
                                      rng=np.random.default_rng(1), rank_stat=stat_fn)
        flags = []
        for _ in range(n_trials):
            idx = rng.integers(0, base["X_pool_s"].shape[0], size=W)
            Xw, Zw = base["X_pool_s"][idx], base["Z_pool"][idx]
            s1 = predictive_entropy(base["clf"].predict_proba(Xw))
            s2 = maha.score(Zw)
            flags.append(tau_guard_test(s1, s2, calib)["flag"])
        results[name] = {"control_fpr": float(np.mean(flags))}
        print(f"rank_stat={name}: control_fpr={np.mean(flags):.3f}")
    return results


def main():
    base = prepare_base("synthetic", seed=1)
    print("=== Window size ablation ===")
    r1 = run_ablation_window_size(base)
    print("=== Bootstrap size ablation ===")
    r2 = run_ablation_bootstrap_size(base)
    print("=== Novelty score ablation ===")
    r3 = run_ablation_novelty_score(base)
    print("=== Rank statistic ablation ===")
    r4 = run_ablation_rank_statistic(base)
    json.dump({"window_size": r1, "bootstrap_size": r2, "novelty_score": r3, "rank_statistic": r4},
               open("/home/claude/paper/results/ablation_results.json", "w"), indent=2)
    print("saved.")


if __name__ == "__main__":
    main()
