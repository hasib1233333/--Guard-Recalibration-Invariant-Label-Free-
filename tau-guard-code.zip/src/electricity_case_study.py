"""
Real-world drift case study: the Electricity (elecNormNew) dataset,
a standard concept-drift benchmark (New South Wales electricity market,
1996-1999) used ubiquitously in the streaming/drift-detection literature.
We process it in its native chronological order (no shuffling), fit on
an early segment, and slide a monitoring window through the rest of the
real historical stream -- a genuine, non-synthetic drift scenario.
"""
import json
import time
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

from method import (
    predictive_entropy, MahalanobisNoveltyScorer,
    calibrate_tau_guard, tau_guard_test,
    calibrate_ks_baseline, ks_baseline_test,
    calibrate_psi_baseline, psi_baseline_test,
    calibrate_mmd_baseline, mmd_baseline_test,
    fit_studd_student, calibrate_studd_baseline, studd_baseline_test,
    calibrate_d3_baseline, d3_baseline_test,
)

WINDOW = 48  # ~1 day of half-hourly readings
ALPHA = 0.05
N_BOOTSTRAP = 1500


def main():
    df = pd.read_csv("/home/claude/paper/data/electricity.csv")
    X = df.drop(columns=["class"]).values.astype(float)
    y = df["class"].values.astype(int)
    n = len(y)
    print("total rows:", n)

    # Chronological split: first 15% to train the classifier and novelty
    # scorer, next 15% as the (still early, presumed-stable) calibration
    # window, remainder is the deployment stream we monitor -- all in
    # real chronological order, no shuffling.
    n_train = int(0.15 * n)
    n_calib = int(0.15 * n)
    X_train, y_train = X[:n_train], y[:n_train]
    X_calib, y_calib = X[n_train:n_train + n_calib], y[n_train:n_train + n_calib]
    X_stream, y_stream = X[n_train + n_calib:], y[n_train + n_calib:]
    print(f"train={len(X_train)} calib={len(X_calib)} stream={len(X_stream)}")

    scaler = StandardScaler().fit(X_train)
    X_train_s, X_calib_s, X_stream_s = scaler.transform(X_train), scaler.transform(X_calib), scaler.transform(X_stream)

    n_comp = min(6, X_train_s.shape[1])
    pca = PCA(n_components=n_comp, random_state=0).fit(X_train_s)
    Z_train, Z_calib, Z_stream = pca.transform(X_train_s), pca.transform(X_calib_s), pca.transform(X_stream_s)

    clf = LogisticRegression(max_iter=2000).fit(X_train_s, y_train)
    novelty = MahalanobisNoveltyScorer(shrinkage=1e-2).fit(Z_train, y_train)
    student = fit_studd_student(X_train_s, clf, lambda: LogisticRegression(max_iter=1000))

    train_acc = (clf.predict(X_train_s) == y_train).mean()
    calib_acc = (clf.predict(X_calib_s) == y_calib).mean()
    print(f"train acc={train_acc:.3f}  calib acc={calib_acc:.3f}")

    s1_calib = predictive_entropy(clf.predict_proba(X_calib_s))
    s2_calib = novelty.score(Z_calib)

    rng = np.random.default_rng(2026)
    t0 = time.time()
    calib = {
        "tau_guard": calibrate_tau_guard(s1_calib, s2_calib, WINDOW, N_BOOTSTRAP, ALPHA, rng=np.random.default_rng(1)),
        "ks": calibrate_ks_baseline(s1_calib, WINDOW, N_BOOTSTRAP, ALPHA, rng=np.random.default_rng(2)),
        "psi": calibrate_psi_baseline(s1_calib, WINDOW, N_BOOTSTRAP, ALPHA, rng=np.random.default_rng(3)),
        "mmd": calibrate_mmd_baseline(Z_calib, WINDOW, N_BOOTSTRAP, ALPHA, rng=np.random.default_rng(4)),
        "studd": calibrate_studd_baseline(X_calib_s, clf, student, WINDOW, N_BOOTSTRAP, ALPHA, rng=np.random.default_rng(5)),
        "d3": calibrate_d3_baseline(X_calib_s, WINDOW, 400, ALPHA, rng=np.random.default_rng(6)),
    }
    print("calibration time:", time.time() - t0)

    # Slide non-overlapping windows through the real chronological stream.
    n_windows = len(X_stream_s) // WINDOW
    print("n_windows:", n_windows)
    records = []
    for w in range(n_windows):
        sl = slice(w * WINDOW, (w + 1) * WINDOW)
        Xw, Zw, yw = X_stream_s[sl], Z_stream[sl], y_stream[sl]
        s1 = predictive_entropy(clf.predict_proba(Xw))
        s2 = novelty.score(Zw)
        acc = float((clf.predict(Xw) == yw).mean())
        rec = {"window": w, "acc": acc}
        rec["tau_guard"] = tau_guard_test(s1, s2, calib["tau_guard"])["flag"]
        rec["ks"] = ks_baseline_test(s1, calib["ks"])["flag"]
        rec["psi"] = psi_baseline_test(s1, calib["psi"])["flag"]
        rec["mmd"] = mmd_baseline_test(Zw, calib["mmd"])["flag"]
        rec["studd"] = studd_baseline_test(Xw, clf, student, calib["studd"])["flag"]
        rec["d3"] = d3_baseline_test(Xw, calib["d3"], rng=rng)["flag"]
        records.append(rec)
        if w % 50 == 0:
            print(f"  window {w}/{n_windows} acc={acc:.3f}")

    out = {"train_acc": train_acc, "calib_acc": calib_acc, "n_windows": n_windows,
           "window_size": WINDOW, "records": records}
    json.dump(out, open("/home/claude/paper/results/electricity_case_study.json", "w"))
    print("saved.")

    methods = ["tau_guard", "ks", "psi", "mmd", "studd", "d3"]
    for m in methods:
        rate = np.mean([r[m] for r in records])
        print(f"{m}: overall flag rate over real stream = {rate:.3f}")


if __name__ == "__main__":
    main()
