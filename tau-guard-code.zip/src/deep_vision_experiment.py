"""
Deep-vision extension study: the same 6-method drift-detection protocol as
the main study, but on real embeddings from a genuine pretrained ResNet-20
CIFAR-10 classifier, with real images and real CIFAR-10-C-style corruptions
(not synthetic PCA-direction perturbations).
"""
import sys
sys.path.insert(0, "/home/claude/paper/src")
import json
import time
import numpy as np
from sklearn.linear_model import LogisticRegression

from deep_vision_features import (
    load_images, extract_features, temp_scaled_entropy_from_images,
    CORRUPTIONS, CLASSES,
)
from method import (
    MahalanobisNoveltyScorer, calibrate_tau_guard, tau_guard_test,
    calibrate_ks_baseline, ks_baseline_test,
    calibrate_psi_baseline, psi_baseline_test,
    calibrate_mmd_baseline, mmd_baseline_test,
    calibrate_d3_baseline, d3_baseline_test,
)

WINDOW = 20
N_BOOTSTRAP = 1500
ALPHA = 0.05


def studd_calibrate_embed(student, s2_calib_emb, teacher_preds_calib, window_size, n_bootstrap, alpha, rng):
    student_preds = student.predict(s2_calib_emb)
    err = (student_preds != teacher_preds_calib).astype(float)
    n = len(err)
    stats_null = np.empty(n_bootstrap)
    for b in range(n_bootstrap):
        idx = rng.integers(0, n, size=window_size)
        stats_null[b] = err[idx].mean()
    thresh = float(np.quantile(stats_null, 1 - alpha))
    return {"thresh": thresh}


def studd_test_embed(student, s2_window_emb, teacher_preds_window, calib):
    student_preds = student.predict(s2_window_emb)
    err = (student_preds != teacher_preds_window).mean()
    return {"stat": float(err), "flag": int(err > calib["thresh"])}


def main(arch="resnet20", out_suffix="", d3_bootstrap=400, n_trials_fpr=150, n_trials_shift=60,
         n_train=150, n_calib=80, n_pool=100, corruption_subset=None):
    t0 = time.time()
    rng = np.random.default_rng(7)

    print("Loading real images and extracting real deep features (ResNet-20 / CIFAR-10)...")
    train_imgs, train_labels = load_images("train", n_per_class=n_train, seed=1)
    calib_imgs, calib_labels = load_images("test", n_per_class=n_calib, seed=2, offset=0)
    pool_imgs, pool_labels = load_images("test", n_per_class=n_pool, seed=3, offset=80)

    s1_train, s2emb_train, preds_train = extract_features(train_imgs, arch=arch)
    s1_calib, s2emb_calib, preds_calib = extract_features(calib_imgs, arch=arch)
    s1_pool, s2emb_pool, preds_pool = extract_features(pool_imgs, arch=arch)
    print(f"  train n={len(train_imgs)} calib n={len(calib_imgs)} pool n={len(pool_imgs)}  "
          f"[{time.time()-t0:.1f}s]")
    print(f"  clean accuracy: train={ (preds_train==train_labels).mean():.3f} "
          f"calib={(preds_calib==calib_labels).mean():.3f} pool={(preds_pool==pool_labels).mean():.3f}")

    novelty = MahalanobisNoveltyScorer(shrinkage=1e-2).fit(s2emb_train, train_labels)
    s2_calib = novelty.score(s2emb_calib)
    s2_pool = novelty.score(s2emb_pool)

    # STUDD student: logistic regression on embeddings, trained to mimic
    # the teacher's predicted labels on the training images
    student = LogisticRegression(max_iter=2000).fit(s2emb_train, preds_train)

    print("Calibrating all methods on real deep-vision signals...")
    calib = {
        "tau_guard": calibrate_tau_guard(s1_calib, s2_calib, WINDOW, N_BOOTSTRAP, ALPHA, rng=np.random.default_rng(10)),
        "ks": calibrate_ks_baseline(s1_calib, WINDOW, N_BOOTSTRAP, ALPHA, rng=np.random.default_rng(11)),
        "psi": calibrate_psi_baseline(s1_calib, WINDOW, N_BOOTSTRAP, ALPHA, rng=np.random.default_rng(12)),
        "mmd": calibrate_mmd_baseline(s2emb_calib, WINDOW, N_BOOTSTRAP, ALPHA, rng=np.random.default_rng(13)),
        "d3": calibrate_d3_baseline(s2emb_calib, WINDOW, d3_bootstrap, ALPHA, rng=np.random.default_rng(14)),
        "studd": studd_calibrate_embed(student, s2emb_calib, preds_calib, WINDOW, N_BOOTSTRAP, ALPHA, rng=np.random.default_rng(15)),
    }
    print(f"  calibration done [{time.time()-t0:.1f}s]")

    # ---- Precompute REAL corrupted versions of the pool images (one
    # inference pass per corruption type), plus their temperature-scaled
    # entropy (for the shift+recalibration scenario, computed consistently
    # rather than mixing scaled/unscaled entropy) ----
    active_corruptions = {k: v for k, v in CORRUPTIONS.items() if corruption_subset is None or k in corruption_subset}
    corrupted_features = {}
    for cname, cfn in active_corruptions.items():
        corrupted_imgs = [cfn(im, severity=3) for im in pool_imgs]
        s1c, s2embc, predsc = extract_features(corrupted_imgs, arch=arch)
        s2c = novelty.score(s2embc)
        s1c_T = temp_scaled_entropy_from_images(corrupted_imgs, T=2.5, arch=arch)
        acc_c = (predsc == pool_labels).mean()
        corrupted_features[cname] = {"s1": s1c, "s1_T": s1c_T, "s2emb": s2embc, "s2": s2c,
                                       "preds": predsc, "acc": float(acc_c)}
        print(f"  corruption={cname}: real accuracy under corruption={acc_c:.3f} "
              f"[{time.time()-t0:.1f}s]")

    def eval_window(idx, s1_override=None, use_corrupt=None, mask=None):
        """idx: indices into the pool arrays. use_corrupt: corruption name
        or None. mask: boolean array selecting which samples (within idx)
        get the corrupted version (for partial-contamination scenarios)."""
        if use_corrupt is None:
            s1 = s1_pool[idx] if s1_override is None else s1_override
            s2emb = s2emb_pool[idx]
            s2 = s2_pool[idx]
            preds = preds_pool[idx]
        else:
            cf = corrupted_features[use_corrupt]
            s1 = s1_pool[idx].copy()
            s2emb = s2emb_pool[idx].copy()
            s2 = s2_pool[idx].copy()
            preds = preds_pool[idx].copy()
            if mask is not None:
                s1[mask] = cf["s1"][idx][mask]
                s2emb[mask] = cf["s2emb"][idx][mask]
                s2[mask] = cf["s2"][idx][mask]
                preds[mask] = cf["preds"][idx][mask]
            if s1_override is not None:
                s1 = s1_override
        out = {}
        out["tau_guard"] = tau_guard_test(s1, s2, calib["tau_guard"])
        out["ks"] = ks_baseline_test(s1, calib["ks"])
        out["psi"] = psi_baseline_test(s1, calib["psi"])
        out["mmd"] = mmd_baseline_test(s2emb, calib["mmd"], rng=rng)
        out["d3"] = d3_baseline_test(s2emb, calib["d3"], rng=rng)
        out["studd"] = studd_test_embed(student, s2emb, preds, calib["studd"])
        return out

    methods = ["tau_guard", "ks", "psi", "mmd", "d3", "studd"]
    n_pool = len(pool_imgs)

    # ---- Scenario A/B: control vs recalibration FPR ----
    print("Running control/recalibration FPR trials...")
    results_fpr = {"control": {m: [] for m in methods}, "recalibration": {m: [] for m in methods}}
    # precompute temperature-scaled entropy for the WHOLE pool once (T=2.5)
    s1_pool_T = temp_scaled_entropy_from_images(pool_imgs, T=2.5, arch=arch)
    for t in range(n_trials_fpr):
        idx = rng.integers(0, n_pool, size=WINDOW)
        out = eval_window(idx)
        for m in methods:
            results_fpr["control"][m].append(out[m]["flag"])
        out_T = eval_window(idx, s1_override=s1_pool_T[idx])
        for m in methods:
            results_fpr["recalibration"][m].append(out_T[m]["flag"])
    print(f"  control FPR: { {m: round(float(np.mean(v)),3) for m,v in results_fpr['control'].items()} }")
    print(f"  recal FPR:   { {m: round(float(np.mean(v)),3) for m,v in results_fpr['recalibration'].items()} }")
    print(f"  [{time.time()-t0:.1f}s]")

    # ---- Scenario C/D: genuine (real) corruption shift, with/without recalibration ----
    print("Running genuine real-corruption shift trials...")
    n_windows = 12
    onset = 4
    results_shift = {}
    for cname in active_corruptions:
        results_shift[cname] = {"shift_only": {m: {"pre": [], "post": []} for m in methods},
                                  "shift_plus_recal": {m: {"pre": [], "post": []} for m in methods}}
        for scenario, apply_recal in [("shift_only", False), ("shift_plus_recal", True)]:
            for trial in range(n_trials_shift):
                flags = {m: np.zeros(n_windows, dtype=int) for m in methods}
                for w in range(n_windows):
                    idx = rng.integers(0, n_pool, size=WINDOW)
                    if w >= onset:
                        mask = rng.random(WINDOW) < 0.4
                        s1_override = None
                        if apply_recal:
                            s1_override = s1_pool_T[idx].copy()
                            s1_override[mask] = corrupted_features[cname]["s1_T"][idx][mask]
                        out = eval_window(idx, use_corrupt=cname, mask=mask, s1_override=s1_override if apply_recal else None)
                    else:
                        s1_override = s1_pool_T[idx] if apply_recal else None
                        out = eval_window(idx, s1_override=s1_override)
                    for m in methods:
                        flags[m][w] = out[m]["flag"]
                for m in methods:
                    results_shift[cname][scenario][m]["pre"].append(float(flags[m][:onset].mean()))
                    results_shift[cname][scenario][m]["post"].append(float(flags[m][onset:].mean()))
        print(f"  corruption={cname} done [{time.time()-t0:.1f}s]")

    out = {
        "clean_acc": {"train": float((preds_train == train_labels).mean()),
                      "calib": float((preds_calib == calib_labels).mean()),
                      "pool": float((preds_pool == pool_labels).mean())},
        "corruption_acc": {c: corrupted_features[c]["acc"] for c in active_corruptions},
        "fpr": results_fpr,
        "shift": results_shift,
        "n_train": len(train_imgs), "n_calib": len(calib_imgs), "n_pool": len(pool_imgs),
        "window": WINDOW,
    }
    json.dump(out, open(f"/home/claude/paper/results/deep_vision_results{out_suffix}.json", "w"), indent=2)
    print(f"saved. total time {time.time()-t0:.1f}s")


if __name__ == "__main__":
    import sys
    arch = sys.argv[1] if len(sys.argv) > 1 else "resnet20"
    suffix = "" if arch == "resnet20" else f"_{arch}"
    main(arch=arch, out_suffix=suffix)
