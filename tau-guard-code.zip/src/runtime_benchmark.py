import json
import time
import tracemalloc
import numpy as np
from experiment_core import prepare_dataset, calibrate_all_methods, sample_window, eval_window

N_REPEATS = 200


def benchmark_dataset(dsname, clf_name="logreg", seed=999):
    rng = np.random.default_rng(seed)
    ds = prepare_dataset(dsname, clf_name, rng)

    # --- calibration cost (one-time, per deployment) ---
    tracemalloc.start()
    t0 = time.perf_counter()
    calib = calibrate_all_methods(ds, rng)
    calib_time = time.perf_counter() - t0
    _, calib_peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()

    # --- per-window inference cost (steady-state monitoring) ---
    per_method_time = {m: [] for m in calib}
    windows = [sample_window(ds, rng) for _ in range(N_REPEATS)]
    for X_win, Z_win, idx in windows:
        s1 = None
        for m in calib:
            t0 = time.perf_counter()
            out = eval_window(ds, {m: calib[m]}, X_win, Z_win, rng=rng)
            per_method_time[m].append(time.perf_counter() - t0)

    # --- stored-state size (bytes), via pickle serialization for a true
    # (not shallow) measurement of what must be persisted between windows ---
    import pickle
    storage_bytes = {}
    storage_bytes["tau_guard"] = len(pickle.dumps((ds["s1_calib"], ds["s2_calib"], calib["tau_guard"]["tau0"],
                                                     calib["tau_guard"]["lo"], calib["tau_guard"]["hi"])))
    storage_bytes["ks"] = len(pickle.dumps(calib["ks"]["reference"]))
    storage_bytes["psi"] = len(pickle.dumps(calib["psi"]["reference"]))
    storage_bytes["mmd"] = len(pickle.dumps(calib["mmd"]["reference"]))
    storage_bytes["studd"] = len(pickle.dumps(ds["student"]))  # full trained auxiliary model
    storage_bytes["d3"] = len(pickle.dumps(calib["d3"]["reference"]))

    return {
        "dataset": dsname, "n_features": ds["n_features"], "window": ds["window"],
        "calib_time_sec": calib_time, "calib_peak_memory_bytes": calib_peak,
        "per_window_time_ms": {m: float(np.mean(v) * 1000) for m, v in per_method_time.items()},
        "per_window_time_std_ms": {m: float(np.std(v) * 1000) for m, v in per_method_time.items()},
        "storage_bytes": storage_bytes,
    }


def main():
    results = {}
    for dsname in ["breast_cancer", "digits", "banknote"]:
        print("benchmarking", dsname)
        results[dsname] = benchmark_dataset(dsname)
        print(json.dumps(results[dsname], indent=2))
    json.dump(results, open("/home/claude/paper/results/runtime_benchmark.json", "w"), indent=2)
    print("saved.")


if __name__ == "__main__":
    main()
