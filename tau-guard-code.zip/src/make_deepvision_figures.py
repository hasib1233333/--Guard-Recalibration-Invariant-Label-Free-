import sys
sys.path.insert(0, "/home/claude/paper/src")
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from deep_vision_features import load_images, CORRUPTIONS

FIGDIR = "/home/claude/paper/figures/"
plt.rcParams.update({"font.size": 9})

# ------------------------------------------------------------------
# Figure: real CIFAR-10 images under real CIFAR-10-C-style corruptions
# ------------------------------------------------------------------
rng = np.random.default_rng(42)
imgs, labels = load_images("test", n_per_class=2, seed=99)
sample_idx = [0, 3, 6, 9]  # pick 4 diverse examples
sample_imgs = [imgs[i] for i in sample_idx]

corruption_names = ["clean"] + list(CORRUPTIONS.keys())
fig, axes = plt.subplots(len(corruption_names), len(sample_imgs), figsize=(6.4, 8.0))
for row, cname in enumerate(corruption_names):
    for col, img in enumerate(sample_imgs):
        if cname == "clean":
            show_img = img
        else:
            show_img = CORRUPTIONS[cname](img, severity=3)
        axes[row, col].imshow(show_img)
        axes[row, col].set_xticks([])
        axes[row, col].set_yticks([])
    axes[row, 0].set_ylabel(cname.replace("_", "\n"), fontsize=8, rotation=0, ha="right", va="center")
fig.suptitle("Real CIFAR-10 images under real CIFAR-10-C-style corruptions (severity 3)", fontsize=9, y=0.995)
fig.tight_layout()
fig.savefig(FIGDIR + "fig_deepvision_corruptions.pdf", bbox_inches="tight")
plt.close(fig)
print("saved fig_deepvision_corruptions.pdf")

# ------------------------------------------------------------------
# Figure: deep-vision FPR comparison (control vs recal) and shift gaps
# ------------------------------------------------------------------
d = json.load(open("/home/claude/paper/results/deep_vision_results.json"))
methods = ["tau_guard", "ks", "psi", "mmd", "d3", "studd"]
labels_m = {"tau_guard": r"$\tau$-Guard", "ks": "Conf-KS", "psi": "PSI", "mmd": "MMD", "d3": "D3", "studd": "STUDD"}
colors = {"tau_guard": "#1b6ca8", "ks": "#d9534f", "psi": "#f0ad4e", "mmd": "#5cb85c", "studd": "#9467bd", "d3": "#8c564b"}

fig, axes = plt.subplots(1, 2, figsize=(8.5, 3.0))

ax = axes[0]
x = np.arange(len(methods))
width = 0.35
ctrl = [np.mean(d["fpr"]["control"][m]) for m in methods]
recal = [np.mean(d["fpr"]["recalibration"][m]) for m in methods]
ax.bar(x - width/2, ctrl, width, label="Control", color="#9ecae1", edgecolor="black", linewidth=0.4)
ax.bar(x + width/2, recal, width, label="Recalibrated", color="#08306b", edgecolor="black", linewidth=0.4)
ax.axhline(0.05, color="gray", linestyle="--", linewidth=0.8)
ax.set_xticks(x); ax.set_xticklabels([labels_m[m] for m in methods], rotation=35, ha="right", fontsize=7.5)
ax.set_ylabel("False-positive rate")
ax.set_title("(a) Real ResNet-20/CIFAR-10:\ncontrol vs.\ recalibration FPR", fontsize=8.5)
ax.legend(fontsize=7, frameon=False)

ax = axes[1]
gaps_shift = []
gaps_recal = []
for m in methods:
    g_s, g_r = [], []
    for cname in CORRUPTIONS:
        pre_s = np.mean(d["shift"][cname]["shift_only"][m]["pre"])
        post_s = np.mean(d["shift"][cname]["shift_only"][m]["post"])
        g_s.append(post_s - pre_s)
        pre_r = np.mean(d["shift"][cname]["shift_plus_recal"][m]["pre"])
        post_r = np.mean(d["shift"][cname]["shift_plus_recal"][m]["post"])
        g_r.append(post_r - pre_r)
    gaps_shift.append(np.mean(g_s))
    gaps_recal.append(np.mean(g_r))
ax.bar(x - width/2, gaps_shift, width, label="Shift only", color="#c7e9c0", edgecolor="black", linewidth=0.4)
ax.bar(x + width/2, gaps_recal, width, label="Shift + recalibration", color="#00441b", edgecolor="black", linewidth=0.4)
ax.axhline(0, color="gray", linewidth=0.8)
ax.set_xticks(x); ax.set_xticklabels([labels_m[m] for m in methods], rotation=35, ha="right", fontsize=7.5)
ax.set_ylabel("Post$-$pre onset flag-rate gap")
ax.set_title("(b) Real ResNet-20/CIFAR-10:\nshift-detection gap, avg.\ over 4 real corruptions", fontsize=8.5)
ax.legend(fontsize=7, frameon=False)

fig.tight_layout()
fig.savefig(FIGDIR + "fig_deepvision_results.pdf", bbox_inches="tight")
plt.close(fig)
print("saved fig_deepvision_results.pdf")
