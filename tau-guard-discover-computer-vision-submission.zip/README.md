# tau-Guard: Discover Computer Vision Submission Package

This package contains the complete, self-contained LaTeX source for the
manuscript "tau-Guard: Recalibration-Invariant, Label-Free Drift Detection
for Visual Recognition Systems via Cross-Signal Rank-Agreement Decay"
(Md Hasibuzzaman), formatted for Springer Nature's *Discover Computer Vision*
using the official `sn-jnl` class with the Vancouver numbered reference
style (`sn-vancouver.bst`).

## What's new in this revision (round 4: editorial trim)

Following feedback that the manuscript was too long (~27 pages) with
repeated explanations and too many small tables, this revision:

15. **Fixed a factual inconsistency**: the Experimental Setup still
    claimed "we were unable to include a deep-learning image backbone"
    despite later sections adding real ResNet-20, RepVGG-A0, and CLIP
    validation. Corrected throughout.
16. **Contributions cut from 8 to 5**, consolidating overlapping items.
17. **Table consolidation**: merged the two FPR tables (core + extended
    battery) into one with a Battery column; eliminated the scalar-
    recalibration-exactness table by folding its numbers into a
    parenthetical sentence; converted the 4-row CLIP FPR table into
    inline prose.
18. **Cut the most repetitive material**: the Discussion's outdated
    "what's validated for CV" paragraph (which duplicated the CLIP/deep-
    vision sections and still contained the now-false "couldn't find
    transformer weights" claim) went from ~230 words to ~75 words. Merged
    several short, related Discussion paragraphs. Trimmed the CUSUM,
    cross-architecture, MMD-bug-disclosure, deployment-recommendations,
    corruption-results, Electricity-results, t-SNE, and shift-detection
    paragraphs, and removed self-conscious "reviewers reasonably asked"
    framing in favor of direct statements.
19. **Added the requested Related Work coverage** (uncertainty
    estimation via deep ensembles, dataset-shift-specific uncertainty
    work, foundation-model risk, continual learning) concisely, with
    real verified citations -- 4 new references (49 total, up from 45).
20. **Result: 7,370 to 6,450 words (12.5% reduction), 27 to 25 pages.**
    Cuts stopped short of the requested 15-20% where further trimming
    would have required removing numbers, caveats, or reproducibility
    detail rather than genuine redundancy.

## What's new in this revision (round 3: foundation model + real vision deployment)

Following further feedback that the deep-vision validation should include
a modern foundation model and that the real-world case study should be a
genuine camera/vision deployment rather than a tabular one, this revision
adds, in a single experiment addressing both requests:

10. **A real CLIP ViT-B/32 foundation-model validation** (OpenCLIP,
    LAION-400M-trained, downloaded from a public GitHub release -- we
    searched for DINOv2 and original OpenAI CLIP weights first, but both
    are hosted on non-GitHub infrastructure inaccessible from this
    environment) via real zero-shot classification.
11. **A real camera/photograph-based domain-shift case study**: PACS, a
    standard domain-generalization benchmark of real photographs and real
    stylistically different images (art paintings, cartoons, sketches) of
    the same object categories -- genuine real-world visual domain shift,
    not a synthetic corruption and not a tabular proxy. The
    recalibration-invariance result replicates cleanly; cross-domain
    shift-detection gaps were honestly modest for every method tested,
    because CLIP turns out to be genuinely robust to this style shift
    (94-100% zero-shot accuracy across all four domains) -- reported as an
    interesting, honest finding rather than hidden or spun.
12. **Two more figures** (now 15 total): real PACS sample images across
    all four domains, and the CLIP+PACS results summary.
13. **49 references** (up from 41).
14. Abstract re-trimmed to 249 words after incorporating this addition.

## What's new in this revision (round 2: reviewer corrections)

Following further reviewer feedback that CIFAR-10/ResNet-20 alone would
read as a toy benchmark to top-tier vision reviewers, and requesting a
formal theoretical bound, modern OOD baselines, and a sequential-testing
comparison, this revision adds:

5. **A second, architecturally distinct real deep-vision validation**:
   RepVGG-A0 (1,280-dimensional embedding, 20x larger than ResNet-20's),
   confirming the recalibration-invariance result holds across both
   networks, while honestly reporting that raw shift-sensitivity is
   architecture-dependent (weaker on the stronger, more confident RepVGG
   network). We could not obtain genuine pretrained ViT/Swin weights or
   ImageNet-scale data from this network-restricted, CPU-only environment
   (searched; none accessible), and say so explicitly rather than silently
   omitting the request or fabricating results.
6. **A proven analytical bound** (Proposition, with full proof) on the
   multiclass temperature-scaling residual, as a function of the logit
   margin and temperature -- closing the theoretical gap the exact
   invariance lemma left open, verified numerically with zero violations
   across 7,000+ randomized trials.
7. **An energy-based OOD score** (Liu et al., NeurIPS 2020) added to the
   novelty-score ablation, alongside the existing Mahalanobis/Euclidean/
   k-NN variants -- it achieved the best-calibrated false-positive rate of
   any variant tested, despite being logit-derived rather than
   embedding-derived.
8. **A CUSUM sequential-testing comparison** (Average Run Length and
   detection-delay), replacing the previous "future work" mention with an
   actual implemented and bootstrap-calibrated result. Reported honestly:
   per-window thresholding was faster and more reliable than CUSUM for
   this paper's abrupt-shift scenario, with the reasoning why, not a
   predetermined result in either method's favor.
9. **Abstract trimmed to under 250 words.**

## What was new in the previous revision (round 1)

1. **A genuine deep-vision validation section** (Section 5.5): the full
   six-method protocol re-run on real embeddings from a genuinely pretrained
   ResNet-20 (via `chenyaofo/pytorch-cifar-models`) on real CIFAR-10 images
   (via the `YoongiKim/CIFAR-10-images` GitHub mirror), under real
   CIFAR-10-C-style corruptions (Gaussian noise, motion blur, brightness,
   contrast). This directly addresses the single most common piece of
   reviewer feedback on the previous draft: that the paper's "Visual
   Recognition Systems" framing was not backed by any deep-learning vision
   experiment. Results are reported honestly and in full, including
   corruptions where the shift-detection signal is weak, not only the
   favorable case (motion blur).
2. **A corrected Feature-MMD baseline.** While building the deep-vision
   extension we found and fixed a real bug: the MMD test compared each
   window against a fixed, non-resampled slice of the reference set,
   inconsistent with the bootstrap protocol used elsewhere, and severely
   miscalibrated in the 64-dimensional deep-vision embedding space (FPR
   0.95 before the fix). This also modestly affected the previously-reported
   tabular MMD numbers, so the full core and extended tabular batteries
   were rerun with the fix; all tables in this revision reflect the
   corrected implementation. This is disclosed in the paper itself
   (Section 5.1), not silently corrected.
3. **Two new figures** (now 13 total): real corrupted CIFAR-10 images
   (Fig. 10), and a deep-vision results summary (Fig. 11). All 13 figures
   were re-verified to appear in the compiled PDF in the exact order their
   filenames suggest.
4. **49 references** (up from 35): added citations for ResNet, CIFAR-10,
   the CIFAR-10-C corruption benchmark, and the specific pretrained-weights
   repository used.

## Files

- `main.tex` -- manuscript source
- `references.bib` -- bibliography (49 verified references)
- `main.bbl` -- pre-compiled bibliography
- `sn-jnl.cls`, `sn-vancouver.bst` -- Springer Nature class and bibliography style (bundled)
- `figure1.pdf` ... `figure15.pdf` -- all fifteen figures
- `main.pdf` -- compiled output (25 pages)

## Compiling

```
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

Verified to compile with zero errors and zero undefined references from a
clean directory containing only the files listed above.

## Honest scope of the deep-vision claim

The deep-vision validation is real but deliberately scoped: one small
CIFAR-ResNet architecture, one 32x32 low-resolution dataset, four corruption
types at one severity level. It demonstrates the mechanism transfers to
genuine deep-vision embeddings; it is not a substitute for broader
benchmarking (larger backbones, ImageNet-scale data, vision transformers,
CLIP-style embeddings, the full CIFAR-10-C/ImageNet-C severity sweep) that
a full computer-vision venue would eventually expect. The paper states this
explicitly in Section 8 rather than overclaiming.
